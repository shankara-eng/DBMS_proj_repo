// server/src/server.js
import dotenv from "dotenv";
dotenv.config();

import { connectDB } from "./config/db.js";
import pool from "./config/postgres.js";
import redisClient from "./config/redis.js";
import { createSession, updateRiskScore, getSession } from "./utils/sessionManager.js";
import http from "http";
import { Server } from "socket.io";
import app from "./app.js";
import Event from "./models/Event.js";

// ✅ MongoDB
connectDB();

// ✅ PostgreSQL
pool.connect()
  .then(() => console.log("✅ PostgreSQL connected"))
  .catch((err) => console.error("❌ PostgreSQL error:", err));

// ✅ HTTP server
const server = http.createServer(app);

// ✅ Socket.IO
const io = new Server(server, {
  cors: { origin: "*" },
  maxHttpBufferSize: 10e6, // 10MB for frames
});

// Track active students per exam
const activeStudents = new Map(); // examId -> Map(studentId -> socketId)

io.on("connection", async (socket) => {
  console.log("Client connected:", socket.id);

  // ✅ Student joins exam room
  socket.on("exam:join", async (data) => {
    const { studentId, examId, studentName } = data;
    const room = `exam:${examId}`;
    socket.join(room);
    socket.studentId = studentId;
    socket.examId = examId;
    socket.studentName = studentName;

    // Track active student
    if (!activeStudents.has(examId)) {
      activeStudents.set(examId, new Map());
    }
    activeStudents.get(examId).set(studentId, {
      socketId: socket.id,
      name: studentName,
      joinedAt: Date.now(),
    });

    // Create Redis session
    await createSession(studentId, examId);

    // Notify proctors
    io.to(`proctor:${examId}`).emit("student:joined", {
      studentId,
      studentName,
      socketId: socket.id,
    });

    // If proctor is already monitoring, tell student to start WebRTC
    const proctorRoom = `proctor:${examId}`;
    const proctorSockets = await io.in(proctorRoom).fetchSockets();
    if (proctorSockets.length > 0) {
      socket.emit("proctor:ready", { examId });
    }

    console.log(`📌 Student ${studentName} joined exam ${examId}`);
  });

  // ✅ Proctor joins monitoring room
  socket.on("proctor:join", (data) => {
    const { examId } = data;
    const room = `proctor:${examId}`;
    socket.join(room);
    socket.examId = examId;
    socket.isProctor = true;

    // Send list of currently active students
    const students = activeStudents.get(examId);
    if (students) {
      socket.emit("active:students", Array.from(students.entries()).map(([id, info]) => ({
        studentId: id,
        ...info,
      })));
    }

    // Notify all students in the exam room to start WebRTC
    io.to(`exam:${examId}`).emit("proctor:ready", { examId });

    console.log(`👁️ Proctor joined monitoring for exam ${examId}`);
  });

  // 🚨 Cheating flag events
  socket.on("flag:raised", async (data) => {
    console.log("🚨 FLAG RECEIVED:", data);

    let riskIncrement = 1;
    if (data.type === "NO_FACE") riskIncrement = 5;
    if (data.type === "MULTIPLE_FACE") riskIncrement = 10;
    if (data.type === "LOOKING_AWAY") riskIncrement = 3;
    if (data.type === "TAB_SWITCH_DURATION") riskIncrement = 4;
    if (data.type === "TAB_SWITCH_ONGOING") riskIncrement = 2;

    // Update Redis risk score
    await updateRiskScore(data.studentId, riskIncrement);
    const session = await getSession(data.studentId);

    try {
      // Save to MongoDB
      await Event.create(data);

      // Send to proctor room only (not back to student)
      io.to(`proctor:${data.examId}`).emit("flag:update", {
        ...data,
        riskScore: session?.riskScore || 0,
      });
    } catch (err) {
      console.error("❌ DB error:", err);
    }
  });

  // 🎥 Webcam frames — route to proctor room only
  let camFrameCount = 0;
  socket.on("camera:frame", (data) => {
    const { studentId, examId, frame } = data;
    camFrameCount++;
    if (camFrameCount % 5 === 1) {
      console.log(`📷 camera:frame #${camFrameCount} from student ${studentId} for exam ${examId} (${frame.length} bytes) -> proctor:${examId}`);
    }
    io.to(`proctor:${examId}`).emit("camera:frame", { studentId, frame });
  });

  // 🖥️ Screen share frames — route to proctor room only
  let scrFrameCount = 0;
  socket.on("screen:frame", (data) => {
    const { studentId, examId, frame } = data;
    scrFrameCount++;
    if (scrFrameCount % 5 === 1) {
      console.log(`🖥️ screen:frame #${scrFrameCount} from student ${studentId} for exam ${examId} (${frame.length} bytes) -> proctor:${examId}`);
    }
    io.to(`proctor:${examId}`).emit("screen:frame", { studentId, frame });
  });

  // ============ WebRTC Signaling ============
  socket.on("webrtc:offer", (data) => {
    const { studentId, examId, offer } = data;
    io.to(`proctor:${examId}`).emit("webrtc:offer", { studentId, offer });
    console.log(`🔗 WebRTC offer from student ${studentId} → proctor:${examId}`);
  });

  socket.on("webrtc:answer", (data) => {
    const { studentId, examId, answer } = data;
    const students = activeStudents.get(examId);
    if (students && students.has(studentId)) {
      io.to(students.get(studentId).socketId).emit("webrtc:answer", { answer });
      console.log(`🔗 WebRTC answer → student ${studentId}`);
    }
  });

  socket.on("webrtc:ice-candidate", (data) => {
    const { studentId, examId, candidate, target } = data;
    if (target === "proctor") {
      io.to(`proctor:${examId}`).emit("webrtc:ice-candidate", { studentId, candidate });
    } else {
      const students = activeStudents.get(examId);
      if (students && students.has(studentId)) {
        io.to(students.get(studentId).socketId).emit("webrtc:ice-candidate", { candidate });
      }
    }
  });

  // ✅ Exam started by proctor — notify all students in room
  socket.on("exam:start", (data) => {
    const { examId } = data;
    io.to(`exam:${examId}`).emit("exam:started", { examId });
    console.log(`🚀 Exam ${examId} started by proctor`);
  });

  // ✅ Exam ended by proctor
  socket.on("exam:end", (data) => {
    const { examId } = data;
    io.to(`exam:${examId}`).emit("exam:ended", { examId });
    console.log(`🛑 Exam ${examId} ended by proctor`);
  });

  // ❌ Disconnect
  socket.on("disconnect", () => {
    // Remove from active students
    if (socket.studentId && socket.examId) {
      const students = activeStudents.get(socket.examId);
      if (students) {
        students.delete(socket.studentId);
        io.to(`proctor:${socket.examId}`).emit("student:left", {
          studentId: socket.studentId,
          studentName: socket.studentName,
        });
      }
    }
    console.log("Client disconnected:", socket.id);
  });
});

// ✅ Server start
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});