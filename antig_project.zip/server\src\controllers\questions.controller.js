// server/src/controllers/questions.controller.js
import pool from "../config/postgres.js";

// ✅ Create question
export const createQuestion = async (req, res) => {
  try {
    const { questionText, type, options, correctAnswer, category, difficulty, marks, tags } = req.body;

    const result = await pool.query(
      `INSERT INTO questions (question_text, type, options, correct_answer, category, difficulty, marks, tags)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [questionText, type || "MCQ", JSON.stringify(options || []), correctAnswer, category, difficulty || "Easy", marks || 1, tags]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create question" });
  }
};

// ✅ Get all questions
export const getQuestions = async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM questions ORDER BY id DESC");
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch questions" });
  }
};

// ✅ Update question
export const updateQuestion = async (req, res) => {
  try {
    const { questionText, type, options, correctAnswer, category, difficulty, marks, tags } = req.body;

    const result = await pool.query(
      `UPDATE questions SET question_text=$1, type=$2, options=$3, correct_answer=$4, category=$5, difficulty=$6, marks=$7, tags=$8
       WHERE id=$9 RETURNING *`,
      [questionText, type, JSON.stringify(options || []), correctAnswer, category, difficulty, marks, tags, req.params.id]
    );

    if (result.rows.length === 0) return res.status(404).json({ error: "Question not found" });
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update question" });
  }
};

// ✅ Delete question
export const deleteQuestion = async (req, res) => {
  try {
    await pool.query("DELETE FROM questions WHERE id = $1", [req.params.id]);
    res.json({ message: "Question deleted successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to delete question" });
  }
};