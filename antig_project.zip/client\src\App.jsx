// client/src/App.jsx
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import useStore from "./store/useStore";
import LandingPage from "./pages/LandingPage";
import LoginPage from "./pages/LoginPage";
import StudentDashboard from "./pages/StudentDashboard";
import ExamLobby from "./pages/ExamLobby";
import ExamPage from "./pages/ExamPage";
import ProctorDashboard from "./pages/ProctorDashboard";

function ProtectedRoute({ children, allowedRoles }) {
  const user = useStore((s) => s.user);
  const token = useStore((s) => s.token);

  if (!user || !token) return <Navigate to="/login" />;
  if (allowedRoles && !allowedRoles.includes(user.role)) return <Navigate to="/" />;

  return children;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public */}
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<LoginPage />} />

        {/* Student */}
        <Route path="/student" element={
          <ProtectedRoute allowedRoles={["student"]}>
            <StudentDashboard />
          </ProtectedRoute>
        } />
        <Route path="/exam/lobby/:examId" element={
          <ProtectedRoute allowedRoles={["student"]}>
            <ExamLobby />
          </ProtectedRoute>
        } />
        <Route path="/exam/take/:examId" element={
          <ProtectedRoute allowedRoles={["student"]}>
            <ExamPage />
          </ProtectedRoute>
        } />

        {/* Proctor / Admin */}
        <Route path="/proctor" element={
          <ProtectedRoute allowedRoles={["proctor", "admin"]}>
            <ProctorDashboard />
          </ProtectedRoute>
        } />
        <Route path="/admin" element={
          <ProtectedRoute allowedRoles={["admin"]}>
            <ProctorDashboard />
          </ProtectedRoute>
        } />

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </BrowserRouter>
  );
}