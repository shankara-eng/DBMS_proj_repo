// server/src/app.js
import express from "express";
import cors from "cors";
import authRoutes from "./routes/auth.routes.js";
import examsRoutes from "./routes/exams.routes.js";
import questionsRoutes from "./routes/questions.routes.js";
import answersRoutes from "./routes/answers.routes.js";
import scoresRoutes from "./routes/scores.routes.js";
import sessionsRoutes from "./routes/sessions.routes.js";

const app = express();

app.use(cors());
app.use(express.json({ limit: "50mb" }));

app.use("/api/auth", authRoutes);
app.use("/api/exams", examsRoutes);
app.use("/api/questions", questionsRoutes);
app.use("/api/answers", answersRoutes);
app.use("/api/scores", scoresRoutes);
app.use("/api/sessions", sessionsRoutes);

app.get("/", (req, res) => {
  res.send("Proctor System API running...");
});

export default app;