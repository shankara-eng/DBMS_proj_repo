// server/src/routes/questions.routes.js
import express from "express";
import { authenticateToken, requireRole } from "../middleware/auth.js";
import { createQuestion, getQuestions, updateQuestion, deleteQuestion } from "../controllers/questions.controller.js";

const router = express.Router();

router.get("/", getQuestions);
router.post("/", authenticateToken, requireRole("proctor", "admin"), createQuestion);
router.put("/:id", authenticateToken, requireRole("proctor", "admin"), updateQuestion);
router.delete("/:id", authenticateToken, requireRole("proctor", "admin"), deleteQuestion);

export default router;