import redisClient from "../config/redis.js";

// ✅ create active session
export const createSession = async (
  studentId,
  examId
) => {

  const sessionKey = `session:${studentId}`;

  const sessionData = {
    studentId,
    examId,
    riskScore: 0,
    status: "ACTIVE",
    startedAt: Date.now(),
  };

  await redisClient.set(
    sessionKey,
    JSON.stringify(sessionData)
  );

  console.log(
    `✅ Session created for ${studentId}`
  );
};

// ✅ get session
export const getSession = async (
  studentId
) => {

  const sessionKey = `session:${studentId}`;

  const data = await redisClient.get(sessionKey);

  return JSON.parse(data);
};

// ✅ update risk score
export const updateRiskScore = async (
  studentId,
  increment
) => {

  const session = await getSession(studentId);

  if (!session) return;

  session.riskScore += increment;

  const sessionKey = `session:${studentId}`;

  await redisClient.set(
    sessionKey,
    JSON.stringify(session)
  );

  console.log(
    `⚠️ Updated risk score: ${session.riskScore}`
  );
};