// client/src/pages/StudentDashboard.jsx
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import useStore from "../store/useStore";
import { getExams, registerForExam, getMyExams } from "../services/api";

export default function StudentDashboard() {
  const navigate = useNavigate();
  const user = useStore((s) => s.user);
  const logout = useStore((s) => s.logout);

  const [exams, setExams] = useState([]);
  const [myExams, setMyExams] = useState([]);
  const [tab, setTab] = useState("available");

  const loadData = async () => {
    try {
      const [allRes, myRes] = await Promise.all([getExams(), getMyExams()]);
      setExams(allRes.data);
      setMyExams(myRes.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleRegister = async (examId) => {
    try {
      await registerForExam(examId);
      loadData();
    } catch (err) {
      alert(err.response?.data?.error || "Registration failed");
    }
  };

  const myExamIds = myExams.map((e) => e.id);

  const getStatusBadge = (status) => {
    const styles = {
      draft: "badge-navy",
      ready: "badge-gold",
      live: "badge-green",
      completed: "badge-navy",
    };
    return styles[status] || "badge-navy";
  };

  const getRegBadge = (status) => {
    const styles = {
      registered: "badge-navy",
      in_progress: "badge-gold",
      submitted: "badge-green",
      flagged: "badge-red",
    };
    return styles[status] || "badge-navy";
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Topbar */}
      <nav className="flex items-center justify-between px-6 py-4 border-b border-border bg-surface">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-primary flex items-center justify-center text-accent font-serif font-bold text-sm">P</div>
          <span className="text-lg font-serif font-bold text-primary">ProctorAI</span>
          <span className="badge badge-navy ml-2">Student Portal</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm font-medium text-primary">Welcome, {user?.name}</span>
          <button onClick={() => { logout(); navigate("/"); }} className="text-sm text-danger hover:underline font-medium">
            Logout
          </button>
        </div>
      </nav>

      <div className="max-w-5xl mx-auto px-6 py-8">
        <h1 className="text-3xl font-serif font-bold text-primary mb-2">Student Dashboard</h1>
        <p className="text-muted mb-8">View available exams and access your scheduled tests.</p>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 border-b border-border pb-1">
          {["available", "my-exams"].map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-4 py-2 text-sm font-semibold transition-all border-b-2 ${
                tab === t
                  ? "border-accent text-primary"
                  : "border-transparent text-muted hover:text-primary"
              }`}
            >
              {t === "available" ? "Available Exams" : "My Registered Exams"}
            </button>
          ))}
        </div>

        {/* Available Exams */}
        {tab === "available" && (
          <div className="space-y-4">
            {exams.length === 0 && (
              <div className="card p-8 text-center text-muted">
                No exams available at this time.
              </div>
            )}
            {exams.map((exam) => (
              <div key={exam.id} className="card p-5 border-l-4 border-l-primary">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-lg font-serif font-bold text-primary">{exam.exam_title}</h3>
                    <div className="flex items-center gap-4 mt-2 text-sm text-muted font-medium">
                      <span>{exam.duration} Minutes</span>
                      <span>•</span>
                      <span>{exam.question_count} Questions</span>
                      <span>•</span>
                      <span>{exam.total_marks} Marks</span>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-3">
                    <span className={`badge ${getStatusBadge(exam.status)}`}>
                      {exam.status}
                    </span>
                    {!myExamIds.includes(exam.id) && exam.status !== "draft" && (
                      <button
                        onClick={() => handleRegister(exam.id)}
                        className="btn-outline text-sm py-1.5 px-4"
                      >
                        Register
                      </button>
                    )}
                    {myExamIds.includes(exam.id) && (
                      <span className="text-sm font-semibold text-success flex items-center gap-1">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                        Registered
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* My Exams */}
        {tab === "my-exams" && (
          <div className="space-y-4">
            {myExams.length === 0 && (
              <div className="card p-8 text-center text-muted">
                You haven't registered for any exams yet.
              </div>
            )}
            {myExams.map((exam) => (
              <div key={exam.id} className="card p-5 border-l-4 border-l-accent">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-lg font-serif font-bold text-primary">{exam.exam_title}</h3>
                    <div className="flex items-center gap-4 mt-2 text-sm text-muted font-medium">
                      <span>{exam.duration} Minutes</span>
                      <span>•</span>
                      <span>{exam.total_marks} Marks</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={`badge ${getRegBadge(exam.registration_status)}`}>
                      {exam.registration_status.replace('_', ' ')}
                    </span>
                    <span className={`badge ${getStatusBadge(exam.status)}`}>
                      {exam.status}
                    </span>
                    
                    {exam.status === "live" && exam.registration_status === "registered" && (
                      <button
                        onClick={() => navigate(`/exam/lobby/${exam.id}`)}
                        className="btn-accent text-sm py-1.5 px-4 ml-2"
                      >
                        Enter Exam
                      </button>
                    )}
                    {exam.registration_status === "submitted" && (
                      <span className="text-sm font-semibold text-success ml-2">Completed</span>
                    )}
                    {exam.registration_status === "in_progress" && exam.status === "live" && (
                      <button
                        onClick={() => navigate(`/exam/take/${exam.id}`)}
                        className="btn-accent text-sm py-1.5 px-4 ml-2"
                      >
                        Resume
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
