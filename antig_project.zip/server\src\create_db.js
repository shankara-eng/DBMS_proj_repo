import pg from 'pg';
import dotenv from 'dotenv';
dotenv.config();

const { Pool } = pg;

const pool = new Pool({
  user: process.env.PG_USER || "postgres",
  host: process.env.PG_HOST || "localhost",
  database: "postgres", // connect to default DB
  password: process.env.PG_PASSWORD || "PSQL",
  port: parseInt(process.env.PG_PORT) || 5432,
});

async function createDb() {
  try {
    const res = await pool.query(`SELECT 1 FROM pg_database WHERE datname = 'proctor_system'`);
    if (res.rows.length === 0) {
      console.log("Database does not exist. Creating...");
      await pool.query('CREATE DATABASE proctor_system;');
      console.log("Database created.");
    } else {
      console.log("Database already exists.");
    }
  } catch (err) {
    console.error("Error creating database:", err);
  } finally {
    pool.end();
  }
}

createDb();
