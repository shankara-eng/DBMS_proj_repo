# 🎓 Online Proctoring System

A full-stack real-time exam proctoring platform. Students take exams through a secure browser with live webcam + screen monitoring. Proctors watch all students simultaneously via a live dashboard. Cheating is automatically detected and flagged with risk scores.

---

## 📁 Project Structure

```
antig/
├── client/                    # React frontend (Vite)
│   └── src/
│       ├── pages/             # ExamPage, ProctorDashboard, StudentDashboard, LoginPage, LandingPage, ExamLobby
│       ├── components/        # WebcamFeed (face detection + frame capture)
│       ├── services/          # api.js (axios), socket.js (socket.io-client)
│       └── store/             # useStore.js (Zustand global state)
└── server/                    # Node.js + Express backend
    └── src/
        ├── app.js             # Express app + route mounting
        ├── server.js          # HTTP server + Socket.IO + WebRTC signaling
        ├── config/
        │   ├── db.js          # MongoDB (Mongoose) connection
        │   ├── postgres.js    # PostgreSQL (pg Pool) connection
        │   ├── redis.js       # Redis client connection
        │   └── schema.sql     # Full PostgreSQL schema
        ├── controllers/       # Business logic (auth, exams, answers, scores, questions, sessions)
        ├── routes/            # Express routers (auth, exams, questions, answers, scores, sessions)
        ├── middleware/        # JWT auth middleware + role guard
        ├── models/            # Mongoose models (Event.js)
        └── utils/             # sessionManager.js (Redis session helpers)
```

---

## 🛠️ Tools & Technology Stack

### Frontend

| Tool | Version | Purpose |
|---|---|---|
| **React** | 18 | UI component framework |
| **Vite** | 5 | Dev server and bundler |
| **React Router DOM** | 6 | Client-side routing |
| **Zustand** | 4 | Global state management |
| **Axios** | 1.x | HTTP requests to REST API |
| **Socket.IO Client** | 4.x | WebSocket connection to server |
| **face-api.js** | 0.22 | In-browser face detection (TinyFaceDetector model) |
| **WebRTC API** | Browser native | Peer-to-peer live video/audio to proctor |
| **TailwindCSS** | 3 | Utility CSS styling |
| **MediaDevices API** | Browser native | Camera and screen capture |

### Backend

| Tool | Version | Purpose |
|---|---|---|
| **Node.js** | 18+ | JavaScript runtime |
| **Express.js** | 4 | REST API framework |
| **Socket.IO** | 4.x | WebSocket server for real-time events |
| **pg (node-postgres)** | 8 | PostgreSQL driver (connection pool) |
| **Mongoose** | 7 | MongoDB ODM |
| **redis** | 4 | Redis client |
| **jsonwebtoken (JWT)** | 9 | Auth token generation and verification |
| **bcryptjs** | 2 | Password hashing |
| **cors** | 2 | Cross-origin request handling |
| **dotenv** | 16 | Environment variable loading |

### Databases

| Database | Why Used | What It Stores |
|---|---|---|
| **PostgreSQL** | ACID compliance, relational integrity, complex joins for academic data | Users, exams, questions, answers, scores, disputes, registrations |
| **MongoDB** | Schema-flexible, high-frequency event logs that vary in shape | Proctoring cheating flag events (NO_FACE, TAB_SWITCH, etc.) |
| **Redis** | In-memory, sub-millisecond reads/writes for live session state | Active exam sessions, real-time risk scores |

### Dev Tools

| Tool | Purpose |
|---|---|
| **ESLint** | Code linting |
| **Nodemon / node --watch** | Auto-restart server on file change |
| **PostCSS** | CSS processing |
| **pgAdmin / psql** | PostgreSQL administration |
| **MongoDB Compass** | MongoDB GUI |
| **Redis CLI** | Redis inspection |

---

## 🗄️ Database 1: PostgreSQL — Why & What

### Why PostgreSQL?
PostgreSQL is used for all **structured, relational, ACID-critical** data. Exams relate to questions, students relate to exams, answers relate to questions — all of these require foreign keys, joins, and transactional integrity. You can't afford a score to be written half-way. PostgreSQL guarantees that either the full score is written or nothing is.

### Connection
```js
// server/src/config/postgres.js
const pool = new Pool({
  user: process.env.PG_USER,
  host: process.env.PG_HOST,
  database: process.env.PG_DATABASE,   // "proctor_system"
  password: process.env.PG_PASSWORD,
  port: 5432,
});
```

### Tables

#### `users` — All accounts (students, proctors, admins)

| Column | Type | Description |
|---|---|---|
| `id` | SERIAL PK | Auto-incremented user ID |
| `name` | VARCHAR(255) | Full name |
| `email` | VARCHAR(255) UNIQUE | Login email |
| `password` | VARCHAR(255) | bcrypt hashed password |
| `role` | VARCHAR(20) | `'student'`, `'proctor'`, or `'admin'` |
| `created_at` | TIMESTAMP | Registration time |

**How a student/faculty registers:**
1. User submits name, email, password, role via `POST /api/auth/register`
2. Controller hashes password with `bcryptjs`
3. `INSERT INTO users` — row written to PostgreSQL
4. JWT token returned to client, stored in Zustand store

---

#### `exams` — Exam definitions

| Column | Type | Description |
|---|---|---|
| `id` | SERIAL PK | Exam ID |
| `exam_title` | VARCHAR(255) | Name of the exam |
| `duration` | INTEGER | Duration in minutes |
| `total_marks` | INTEGER | Sum of all question marks |
| `start_time` | TIMESTAMP | Scheduled start |
| `end_time` | TIMESTAMP | Scheduled end |
| `status` | VARCHAR(20) | `draft` → `ready` → `live` → `completed` |
| `proctoring_settings` | JSONB | Flexible settings (e.g., face check on/off) |
| `created_by` | FK → users.id | Which proctor created it |
| `created_at` | TIMESTAMP | Creation time |

**How an exam is created:**
1. Proctor fills out exam form in UI → clicks "Create Exam"
2. `POST /api/exams` hit with `{ exam_title, duration, start_time, ... }`
3. `authenticateToken` middleware verifies JWT, `requireRole('proctor','admin')` checks role
4. `INSERT INTO exams` — row written to PostgreSQL
5. Exam ID returned; proctor then adds questions via `POST /api/exams/:id/questions`

---

#### `questions` — Question bank

| Column | Type | Description |
|---|---|---|
| `id` | SERIAL PK | Question ID |
| `question_text` | TEXT | The actual question |
| `type` | VARCHAR(30) | `'MCQ'` (default) |
| `options` | JSONB | Array of answer strings e.g. `["Paris","London","Rome","Berlin"]` |
| `correct_answer` | TEXT | Correct option letter e.g. `"A"` |
| `category` | VARCHAR(100) | Subject/topic |
| `difficulty` | VARCHAR(50) | `Easy`, `Medium`, `Hard` |
| `marks` | INTEGER | Points for this question |
| `tags` | TEXT | Comma-separated tags |
| `created_at` | TIMESTAMP | Creation time |

---

#### `exam_questions` — Links exams to questions (many-to-many)

| Column | Type | Description |
|---|---|---|
| `id` | SERIAL PK | Row ID |
| `exam_id` | FK → exams.id | Which exam |
| `question_id` | FK → questions.id | Which question |

**How questions are added to an exam:**
1. Proctor clicks "Add Question" in exam editor UI
2. `POST /api/exams/:id/questions` with `{ question_text, options, correct_answer, marks, ... }`
3. Controller first `INSERT INTO questions` to create the question
4. Then `INSERT INTO exam_questions (exam_id, question_id)` to link it
5. `total_marks` on the exam row is also `UPDATE`d

---

#### `exam_registrations` — Student enrollment per exam

| Column | Type | Description |
|---|---|---|
| `id` | SERIAL PK | Row ID |
| `student_id` | FK → users.id | Which student |
| `exam_id` | FK → exams.id | Which exam |
| `status` | VARCHAR(30) | `registered` → `in_progress` → `submitted` / `flagged` |
| `risk_score` | INTEGER | Cumulative cheating risk (default 0) |
| `started_at` | TIMESTAMP | When student clicked "Start Exam" |
| `submitted_at` | TIMESTAMP | When student submitted |
| `created_at` | TIMESTAMP | When they registered |

**Unique constraint:** `(student_id, exam_id)` — one row per student per exam.

---

#### `student_answers` — Per-question answers

| Column | Type | Description |
|---|---|---|
| `id` | SERIAL PK | Row ID |
| `student_id` | FK → users.id | Who answered |
| `exam_id` | FK → exams.id | Which exam |
| `question_id` | FK → questions.id | Which question |
| `selected_answer` | TEXT | Answer letter e.g. `"B"` |
| `answered_at` | TIMESTAMP | When the answer was saved |

**Unique constraint:** `(student_id, exam_id, question_id)` — upserted on every click.

**How answers are saved:**
1. Student clicks an option in ExamPage → `handleAnswer()` called
2. `POST /api/answers` with `{ exam_id, question_id, selected_answer }`
3. `INSERT INTO student_answers ... ON CONFLICT ... DO UPDATE` — immediate upsert
4. Student can change answers any time before submit

---

#### `scores` — Final computed scores

| Column | Type | Description |
|---|---|---|
| `id` | SERIAL PK | Row ID |
| `student_id` | FK → users.id | Student |
| `exam_id` | FK → exams.id | Exam |
| `score` | INTEGER | Total marks earned |
| `total` | INTEGER | Maximum possible marks |
| `percentage` | DECIMAL(5,2) | Score percentage |
| `created_at` | TIMESTAMP | When score was computed |

**How score is calculated:**
1. Student clicks "Submit Assessment"
2. `POST /api/answers/:examId/submit` called
3. Controller queries `student_answers JOIN questions` for that student+exam
4. Compares `selected_answer = correct_answer` per question, sums marks
5. `INSERT INTO scores` with computed values (upserted)
6. `exam_registrations.status` → `'submitted'`, `submitted_at` set
7. Score object returned to client, shown on result screen

---

#### `disputes` — Student score disputes

| Column | Type | Description |
|---|---|---|
| `id` | SERIAL PK | Row ID |
| `student_id` | FK → users.id | Student raising dispute |
| `exam_id` | FK → exams.id | Exam in question |
| `reason` | TEXT | Dispute reason text |
| `status` | VARCHAR(20) | `pending` → `reviewing` → `resolved` / `rejected` |
| `resolution` | TEXT | Proctor's resolution note |
| `resolved_by` | FK → users.id | Proctor who resolved |
| `created_at` | TIMESTAMP | Filed at |
| `resolved_at` | TIMESTAMP | Resolved at |

---

#### `audit_log` — System event log

| Column | Type | Description |
|---|---|---|
| `id` | SERIAL PK | Row ID |
| `user_id` | FK → users.id | Who performed the action |
| `action` | VARCHAR(100) | Action label e.g. `'LOGIN'`, `'SUBMIT_EXAM'` |
| `details` | JSONB | Flexible extra data |
| `ip_address` | VARCHAR(45) | Client IP |
| `created_at` | TIMESTAMP | Timestamp |

---

## 🍃 Database 2: MongoDB — Why & What

### Why MongoDB?
Proctoring events are **high-frequency, variable-shape data**. A `NO_FACE` event has a `confidence` score. A `TAB_SWITCH_DURATION` event has a `duration`. A `MULTIPLE_FACE` event might have `count`. Forcing these into a fixed SQL schema would require nullable columns everywhere or a separate table per event type. MongoDB's document model handles this naturally — each event document contains exactly the fields it needs.

### Connection
```js
// server/src/config/db.js
await mongoose.connect(process.env.MONGO_URI);
```

### Collection: `events` (via `Event.js` Mongoose model)

| Field | Type | Description |
|---|---|---|
| `studentId` | String (indexed) | Student who triggered the event |
| `examId` | String (indexed) | Exam during which it happened |
| `type` | String | `NO_FACE`, `MULTIPLE_FACE`, `LOOKING_AWAY`, `TAB_SWITCH_DURATION`, `TAB_SWITCH_ONGOING` |
| `confidence` | Number | Face detection confidence (0-1) |
| `duration` | Number | Duration in seconds (for tab switch events) |
| `details` | Mixed | Any extra data (flexible BSON) |
| `timestamp` | Number | Unix ms timestamp |
| `createdAt` | Date | Mongoose auto-timestamp |
| `updatedAt` | Date | Mongoose auto-timestamp |

**How events are stored:**
1. `WebcamFeed.jsx` runs face detection every 5 seconds using `face-api.js TinyFaceDetector`
2. If `detections.length === 0` for 2 consecutive checks → `triggerAlert("NO_FACE")`
3. If `detections.length > 1` → `triggerAlert("MULTIPLE_FACE")`
4. If face center deviates >120px from frame center → `triggerAlert("LOOKING_AWAY")`
5. `socket.emit("flag:raised", event)` sent to server
6. Server `flag:raised` handler calls `Event.create(data)` → written to MongoDB
7. Also forwarded to `proctor:${examId}` room as `flag:update`

**Tab switch detection** (in `ExamPage.jsx`):
- `document.addEventListener("visibilitychange")` fires when student tabs away
- Every 3 seconds while hidden → `TAB_SWITCH_ONGOING` event emitted
- When tab returns → `TAB_SWITCH_DURATION` event with total seconds away emitted

---

## 🔴 Database 3: Redis — Why & What

### Why Redis?
During a live exam, risk scores are updated every few seconds (every flag event). Writing to PostgreSQL each time would be slow and create heavy DB load. Redis stores the session in memory — reads and writes complete in under 1ms. At exam end, the final risk score is written back to PostgreSQL `exam_registrations.risk_score`.

### Connection
```js
// server/src/config/redis.js
const redisClient = createClient();
await redisClient.connect();
```

### Key Pattern: `session:<studentId>`

Each active exam session is stored as a JSON string:

```json
{
  "studentId": "3",
  "examId": "1",
  "riskScore": 17,
  "status": "ACTIVE",
  "startedAt": 1715241234567
}
```

### Session Manager Functions (`utils/sessionManager.js`)

| Function | What it does |
|---|---|
| `createSession(studentId, examId)` | Creates key `session:<studentId>` in Redis with `riskScore: 0` when student joins exam room |
| `getSession(studentId)` | Fetches and parses the session JSON from Redis |
| `updateRiskScore(studentId, increment)` | Gets session, adds increment to `riskScore`, writes back |

### Risk Score Increments (defined in `server.js`)

| Flag Type | Risk Points Added |
|---|---|
| `NO_FACE` | +5 |
| `MULTIPLE_FACE` | +10 |
| `LOOKING_AWAY` | +3 |
| `TAB_SWITCH_DURATION` | +4 |
| `TAB_SWITCH_ONGOING` | +2 |

---

## 🌐 REST API Endpoints

### Auth — `/api/auth`

| Method | Route | Auth | Description |
|---|---|---|---|
| POST | `/login` | None | Login with email+password, returns JWT |
| POST | `/register` | None | Register new user (any role) |
| GET | `/me` | JWT | Get current user from token |

### Exams — `/api/exams`

| Method | Route | Auth | Description |
|---|---|---|---|
| GET | `/` | None | List all exams |
| GET | `/my-exams` | Student JWT | Get exams the student is registered for |
| GET | `/:id` | None | Get single exam details |
| GET | `/:id/questions` | JWT | Get questions for an exam |
| GET | `/:id/students` | Proctor/Admin JWT | Get registered students for an exam |
| POST | `/` | Proctor/Admin JWT | Create a new exam |
| PATCH | `/:id/status` | Proctor/Admin JWT | Update exam status (draft→ready→live→completed) |
| POST | `/:id/questions` | Proctor/Admin JWT | Add a question to an exam |
| POST | `/:id/register` | Student JWT | Register student for an exam |
| POST | `/:id/start` | Student JWT | Mark student as `in_progress`, set `started_at` |

### Answers — `/api/answers`

| Method | Route | Auth | Description |
|---|---|---|---|
| POST | `/` | JWT | Submit/update one answer (upsert) |
| GET | `/:examId` | JWT | Get student's saved answers for an exam |
| POST | `/:examId/submit` | JWT | Submit exam, calculate and store score |

### Scores — `/api/scores`

| Method | Route | Auth | Description |
|---|---|---|---|
| POST | `/calculate` | None | Manually trigger score calculation |
| GET | `/` | None | Get all scores |

### Sessions — `/api/sessions`

| Method | Route | Auth | Description |
|---|---|---|---|
| GET | `/` | JWT | Get active Redis session for current student |

---

## ⚡ Real-Time Layer — Socket.IO Events

All real-time communication goes through a single Socket.IO server running on port 5000. There are two types of rooms: `exam:<examId>` (students) and `proctor:<examId>` (proctors).

### Student → Server Events

| Event | Payload | What happens |
|---|---|---|
| `exam:join` | `{ studentId, examId, studentName }` | Student joins `exam:<examId>` room; Redis session created; proctor notified |
| `flag:raised` | `{ studentId, examId, type, ... }` | Risk score updated in Redis; event saved to MongoDB; alert forwarded to proctor room |
| `camera:frame` | `{ studentId, examId, frame }` | JPEG frame (base64) forwarded to `proctor:<examId>` room |
| `screen:frame` | `{ studentId, examId, frame }` | Screen frame forwarded to proctor room |
| `webrtc:offer` | `{ studentId, examId, offer }` | SDP offer forwarded to proctor room for WebRTC setup |
| `webrtc:ice-candidate` | `{ studentId, examId, candidate, target }` | ICE candidate forwarded to proctor or student |

### Proctor → Server Events

| Event | Payload | What happens |
|---|---|---|
| `proctor:join` | `{ examId }` | Proctor joins `proctor:<examId>` room; receives active student list; all students notified to start WebRTC |
| `webrtc:answer` | `{ studentId, examId, answer }` | SDP answer forwarded to specific student's socket |
| `webrtc:ice-candidate` | `{ studentId, examId, candidate }` | ICE candidate forwarded to student |
| `exam:start` | `{ examId }` | All students in `exam:<examId>` get `exam:started` event |
| `exam:end` | `{ examId }` | All students get `exam:ended` → auto-submit triggered |

### Server → Client Events

| Event | Sent To | Description |
|---|---|---|
| `student:joined` | Proctor room | New student joined the exam |
| `student:left` | Proctor room | Student disconnected |
| `active:students` | Joining proctor | List of currently connected students |
| `flag:update` | Proctor room | Cheating flag with updated risk score |
| `camera:frame` | Proctor room | Live webcam frame from a student |
| `screen:frame` | Proctor room | Live screen frame from a student |
| `proctor:ready` | Student | Tells student to initiate WebRTC offer |
| `exam:started` | Exam room | Exam has been started by proctor |
| `exam:ended` | Exam room | Exam ended — triggers auto-submit |

---

## 🎥 Video Data — How It Works

Video data is **never stored to disk or database**. It flows in real-time only.

### Path 1: Frame Relay (Socket.IO)
```
Student Browser
  → Canvas captures video frame every 3 seconds (240×180px, JPEG quality 0.25)
  → Encoded as base64 string (DataURL)
  → socket.emit("camera:frame", { studentId, examId, frame })
  → Server receives → io.to("proctor:<examId>").emit("camera:frame", { studentId, frame })
  → Proctor browser renders frame in an <img> tag
```

### Path 2: Live Video (WebRTC P2P)
```
Student Browser
  → navigator.mediaDevices.getUserMedia({ video: true, audio: true })
  → RTCPeerConnection created with STUN server (stun.l.google.com:19302)
  → Tracks added to peer connection
  → SDP Offer created → sent via socket "webrtc:offer"
  → Server relays offer to proctor room
  → Proctor receives offer → creates answer → sends via "webrtc:answer"
  → Student receives answer → sets remote description
  → ICE candidates exchanged via "webrtc:ice-candidate"
  → Direct P2P connection established
  → Proctor sees live video+audio in <video> element (no server in the path)
```

### Screen Share
```
Student Browser
  → navigator.mediaDevices.getDisplayMedia({ video: true })
  → Canvas captures screen every 3 seconds (480×270px, JPEG quality 0.25)
  → socket.emit("screen:frame", { studentId, examId, frame })
  → Server relays to proctor room
```

**Nothing is recorded or persisted** — video is live-only.

---

## 🧠 Face Detection — How It Works

`face-api.js` runs entirely **in the browser**. No video is sent to a server for analysis.

1. `TinyFaceDetector` model loaded from `/public/models/` on ExamPage mount
2. Every **5 seconds**, `faceapi.detectAllFaces(videoElement)` runs
3. Results:
   - **0 faces** → `noFaceCount++`; if ≥ 2 consecutive → emit `NO_FACE` flag
   - **>1 face** → emit `MULTIPLE_FACE` flag immediately
   - **1 face, off-center** → if face center deviates >120px → emit `LOOKING_AWAY`
4. Flag emitted via socket → server → MongoDB + Redis risk score update → proctor alert

---

## 🔐 Authentication & Authorization

### JWT Flow
1. `POST /api/auth/login` → server verifies email/password → returns `{ token, user }`
2. Token stored in Zustand `useStore` (in-memory, not localStorage)
3. Every API request sends `Authorization: Bearer <token>` header
4. `authenticateToken` middleware verifies token, attaches `req.user`
5. `requireRole(...roles)` middleware checks `req.user.role` against allowed roles

### Role Permissions

| Feature | Student | Proctor | Admin |
|---|---|---|---|
| Register for exam | ✅ | ❌ | ❌ |
| Take exam | ✅ | ❌ | ❌ |
| Create exam | ❌ | ✅ | ✅ |
| Add questions | ❌ | ✅ | ✅ |
| Change exam status | ❌ | ✅ | ✅ |
| View proctor dashboard | ❌ | ✅ | ✅ |
| View student list | ❌ | ✅ | ✅ |

---

## 🔒 Anti-Cheating Measures

| Measure | Implementation |
|---|---|
| **Copy/Paste blocked** | `copy`, `paste`, `cut`, `contextmenu` events `preventDefault()`-ed in ExamPage |
| **Keyboard shortcuts blocked** | Ctrl+C, Ctrl+V, Ctrl+X, Ctrl+A intercepted and cancelled |
| **Tab switch detection** | `visibilitychange` event tracks when student leaves exam tab |
| **Face detection** | face-api.js TinyFaceDetector runs every 5s in browser |
| **No face detected** | Flagged as `NO_FACE` after 2 consecutive misses |
| **Multiple faces** | Flagged as `MULTIPLE_FACE` immediately |
| **Looking away** | Flagged as `LOOKING_AWAY` if face center off by >120px |
| **Risk scoring** | All flags add to a cumulative risk score in Redis, shown live to proctor |
| **Live monitoring** | Proctor sees all students' webcams + screens simultaneously |

---

## 🚀 Running Locally

### Prerequisites
- Node.js 18+
- PostgreSQL running locally (database: `proctor_system`)
- MongoDB running locally (or Atlas URI)
- Redis running locally on default port 6379

### Setup

```bash
# 1. Clone and install root deps
cd antig && npm install

# 2. Install server deps
cd server && npm install

# 3. Install client deps
cd ../client && npm install

# 4. Setup environment
# Edit server/.env:
PG_USER=postgres
PG_PASSWORD=yourpassword
PG_DATABASE=proctor_system
MONGO_URI=mongodb://localhost:27017/proctor_system
JWT_SECRET=your_secret_key

# 5. Initialize PostgreSQL schema
psql -U postgres -d proctor_system -f server/src/config/schema.sql

# 6. Seed demo data (optional)
cd server && node src/seed_demo_exam.js

# 7. Start server (port 5000)
cd server && npm run dev

# 8. Start client (port 5173)
cd client && npm run dev
```

### Demo Credentials

| Role | Email | Password |
|---|---|---|
| Admin | admin@proctor.com | admin123 |
| Proctor | proctor@proctor.com | proctor123 |
| Student 1 | student@proctor.com | student123 |
| Student 2 | student2@proctor.com | student123 |

---

## 📊 Complete Data Flow Summary

### Registration
```
User fills form → POST /api/auth/register
→ bcrypt.hash(password)
→ INSERT INTO users (name, email, hashed_password, role)
→ JWT returned → stored in Zustand
```

### Exam Creation (Proctor)
```
Proctor fills exam form → POST /api/exams
→ JWT verified + role = proctor/admin
→ INSERT INTO exams → exam_id returned
→ For each question: POST /api/exams/:id/questions
  → INSERT INTO questions → question_id
  → INSERT INTO exam_questions (exam_id, question_id)
  → UPDATE exams SET total_marks = total_marks + marks
```

### Student Joins Exam
```
Student clicks "Start Exam" → POST /api/exams/:id/start
→ UPDATE exam_registrations SET status='in_progress', started_at=NOW()
→ ExamPage loads → socket.emit("exam:join", { studentId, examId })
→ Server: student joins room, Redis session created (riskScore: 0)
→ Camera + screen capture begins
→ Face detection starts
→ WebRTC offer sent (if proctor already in room)
```

### Answer Submission
```
Student clicks option → POST /api/answers { exam_id, question_id, selected_answer }
→ INSERT INTO student_answers ON CONFLICT DO UPDATE
→ Answer saved immediately (auto-save on every click)
```

### Exam Submission
```
Student clicks Submit → POST /api/answers/:examId/submit
→ SELECT student_answers JOIN questions WHERE student_id+exam_id
→ SUM(marks WHERE selected_answer = correct_answer) = score
→ INSERT INTO scores (score, total, percentage)
→ UPDATE exam_registrations SET status='submitted', submitted_at=NOW()
→ Score returned to client → shown on result screen
```

### Cheating Detection
```
face-api.js detects anomaly in browser
→ socket.emit("flag:raised", { studentId, examId, type })
→ Server flag:raised handler:
   1. updateRiskScore(studentId, increment) → Redis updated
   2. Event.create(data) → MongoDB document saved
   3. io.to("proctor:<examId>").emit("flag:update", { ...data, riskScore })
→ Proctor dashboard shows alert with updated risk score
```

---

## 👥 Team

| Name | Roll Number |
|---|---|
| Shankara Vasishta T N | 24UG00541 |
| Suhita Sai Salaka | 24UG00334 |
| Harshal Gowda | 24UG00313 |
| Ganesh Nayak | 24UG00312 |
