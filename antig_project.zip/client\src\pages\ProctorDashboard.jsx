// client/src/pages/ProctorDashboard.jsx
import { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import useStore from "../store/useStore";
import { getExams, createExam, updateExamStatus, addQuestionsToExam, getExamStudents } from "../services/api";
import socket from "../services/socket";

export default function ProctorDashboard() {
  const navigate = useNavigate();
  const user = useStore((s) => s.user);
  const logout = useStore((s) => s.logout);

  const [tab, setTab] = useState("exams");
  const [exams, setExams] = useState([]);
  const [selectedExam, setSelectedExam] = useState(null);
  const [monitoringExamId, setMonitoringExamId] = useState(null);

  // Create exam form
  const [showCreateExam, setShowCreateExam] = useState(false);
  const [examForm, setExamForm] = useState({ exam_title: "", duration: 30, total_marks: 0 });
  const [examQuestions, setExamQuestions] = useState([
    { questionText: "", options: ["", "", "", ""], correctAnswer: "A", difficulty: "Easy", marks: 1 },
  ]);


  // Monitoring state
  const [cameraFrames, setCameraFrames] = useState({});
  const [screenFrames, setScreenFrames] = useState({});
  const [events, setEvents] = useState([]);
  const [students, setStudents] = useState([]);

  // WebRTC state
  const peerConnections = useRef({}); // studentId -> RTCPeerConnection
  const [rtcStreams, setRtcStreams] = useState({}); // studentId -> MediaStream[]

  const loadExams = async () => {
    try {
      const res = await getExams();
      setExams(res.data);
    } catch (err) { console.error(err); }
  };



  useEffect(() => {
    loadExams();
  }, []);

  // ===== CRITICAL: Socket listeners for live monitoring =====
  useEffect(() => {
    if (!monitoringExamId) return;

    // Join the proctor room on the server
    socket.emit("proctor:join", { examId: String(monitoringExamId) });

    socket.on("camera:frame", (data) => {
      setCameraFrames((prev) => ({ ...prev, [data.studentId]: data.frame }));
    });

    socket.on("screen:frame", (data) => {
      setScreenFrames((prev) => ({ ...prev, [data.studentId]: data.frame }));
    });

    socket.on("flag:update", (data) => {
      setEvents((prev) => [data, ...prev].slice(0, 100));
    });

    socket.on("student:joined", (data) => {
      setStudents((prev) => {
        if (prev.find((s) => String(s.studentId || s.id) === String(data.studentId))) return prev;
        return [...prev, data];
      });
    });

    socket.on("student:left", (data) => {
      setStudents((prev) => prev.filter((s) => String(s.studentId || s.id) !== String(data.studentId)));
    });

    socket.on("active:students", (list) => {
      setStudents(list);
    });

    // ============ WebRTC: Receive live video+audio from students ============
    socket.on("webrtc:offer", async (data) => {
      const { studentId, offer } = data;
      console.log(`🔗 Received WebRTC offer from student ${studentId}`);

      try {
        // Close existing connection for this student if any
        if (peerConnections.current[studentId]) {
          peerConnections.current[studentId].close();
        }

        const pc = new RTCPeerConnection({
          iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
        });
        peerConnections.current[studentId] = pc;

        // Collect incoming streams
        const receivedStreams = new Map(); // streamId -> MediaStream
        pc.ontrack = (event) => {
          const stream = event.streams[0];
          if (!receivedStreams.has(stream.id)) {
            receivedStreams.set(stream.id, stream);
            setRtcStreams((prev) => ({
              ...prev,
              [studentId]: Array.from(receivedStreams.values()),
            }));
          }
        };

        // Send ICE candidates back to student
        pc.onicecandidate = (event) => {
          if (event.candidate) {
            socket.emit("webrtc:ice-candidate", {
              studentId,
              examId: String(monitoringExamId),
              candidate: event.candidate,
              target: "student",
            });
          }
        };

        // Set remote description and create answer
        await pc.setRemoteDescription(new RTCSessionDescription(offer));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);

        socket.emit("webrtc:answer", {
          studentId,
          examId: String(monitoringExamId),
          answer,
        });

        console.log(`✅ WebRTC answer sent to student ${studentId}`);
      } catch (err) {
        console.error("WebRTC offer handling error:", err);
      }
    });

    socket.on("webrtc:ice-candidate", async (data) => {
      const { studentId, candidate } = data;
      const pc = peerConnections.current[studentId];
      if (pc && candidate) {
        try {
          await pc.addIceCandidate(new RTCIceCandidate(candidate));
        } catch (err) {
          console.error("ICE candidate error:", err);
        }
      }
    });

    return () => {
      socket.off("camera:frame");
      socket.off("screen:frame");
      socket.off("flag:update");
      socket.off("student:joined");
      socket.off("student:left");
      socket.off("active:students");
      socket.off("webrtc:offer");
      socket.off("webrtc:ice-candidate");
      // Close all peer connections
      Object.values(peerConnections.current).forEach((pc) => pc.close());
      peerConnections.current = {};
      setRtcStreams({});
    };
  }, [monitoringExamId]);

  const handleCreateExam = async (e) => {
    e.preventDefault();
    try {
      // 1. Create the exam
      const totalMarks = examQuestions.reduce((sum, q) => sum + (q.marks || 1), 0);
      const examRes = await createExam({ ...examForm, total_marks: totalMarks });
      const newExamId = examRes.data.id;

      // 2. Create each question and collect their IDs
      const { createQuestion } = await import("../services/api.js");
      const questionIds = [];
      for (const q of examQuestions) {
        const qRes = await createQuestion({
          questionText: q.questionText,
          type: "MCQ",
          options: q.options,
          correctAnswer: q.correctAnswer,
          category: "",
          difficulty: q.difficulty,
          marks: q.marks,
          tags: "",
        });
        questionIds.push(qRes.data.id);
      }

      // 3. Link all questions to the exam
      if (questionIds.length > 0) {
        await addQuestionsToExam(newExamId, questionIds);
      }

      setShowCreateExam(false);
      setExamForm({ exam_title: "", duration: 30, total_marks: 0 });
      setExamQuestions([{ questionText: "", options: ["", "", "", ""], correctAnswer: "A", difficulty: "Easy", marks: 1 }]);
      loadExams();
    } catch (err) {
      console.error(err);
      alert("Failed to create exam");
    }
  };

  const addNewQuestion = () => {
    setExamQuestions([...examQuestions, { questionText: "", options: ["", "", "", ""], correctAnswer: "A", difficulty: "Easy", marks: 1 }]);
  };

  const updateExamQuestion = (index, field, value) => {
    const updated = [...examQuestions];
    updated[index] = { ...updated[index], [field]: value };
    setExamQuestions(updated);
  };

  const updateExamQuestionOption = (qIndex, optIndex, value) => {
    const updated = [...examQuestions];
    const opts = [...updated[qIndex].options];
    opts[optIndex] = value;
    updated[qIndex] = { ...updated[qIndex], options: opts };
    setExamQuestions(updated);
  };

  const removeExamQuestion = (index) => {
    if (examQuestions.length <= 1) return;
    setExamQuestions(examQuestions.filter((_, i) => i !== index));
  };

  const handleStatusChange = async (examId, status) => {
    try {
      await updateExamStatus(examId, status);
      if (status === "live") {
        socket.emit("exam:start", { examId: String(examId) });
      }
      if (status === "completed") {
        socket.emit("exam:end", { examId: String(examId) });
      }
      loadExams();
    } catch (err) { alert("Failed to update status"); }
  };

  const startMonitoring = async (examId) => {
    setMonitoringExamId(examId);
    setTab("monitor");
    try {
      const res = await getExamStudents(examId);
      setStudents(res.data);
    } catch (err) { console.error(err); }
  };

  const getFlagColor = (type) => {
    const colors = {
      NO_FACE: "bg-red-50 border-red-200 text-red-700",
      MULTIPLE_FACE: "bg-red-50 border-red-200 text-red-700",
      LOOKING_AWAY: "bg-yellow-50 border-yellow-200 text-yellow-700",
      TAB_SWITCH_DURATION: "bg-orange-50 border-orange-200 text-orange-700",
      TAB_SWITCH_ONGOING: "bg-orange-50 border-orange-200 text-orange-700",
    };
    return colors[type] || "bg-gray-50 border-gray-200 text-gray-700";
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Topbar */}
      <nav className="flex items-center justify-between px-6 py-4 border-b border-border bg-surface">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-primary flex items-center justify-center text-accent font-serif font-bold text-sm">P</div>
          <span className="text-lg font-serif font-bold text-primary">ProctorAI</span>
          <span className="badge badge-gold ml-2">Faculty Portal</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm font-medium text-primary">{user?.name}</span>
          <button onClick={() => { logout(); navigate("/"); }} className="text-sm text-danger hover:underline font-medium">Logout</button>
        </div>
      </nav>

      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 border-r border-border bg-surface min-h-[calc(100vh-65px)] p-4">
          {[
            { id: "exams", icon: "📋", label: "Exam Management" },
            { id: "monitor", icon: "👁️", label: "Live Monitor" },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              className={`w-full text-left px-4 py-3 rounded-md text-sm font-medium flex items-center gap-3 mb-2 transition-all ${
                tab === item.id 
                  ? "bg-primary text-white shadow-sm" 
                  : "text-muted hover:bg-surfaceAlt hover:text-primary"
              }`}
            >
              <span>{item.icon}</span> {item.label}
              {item.id === "monitor" && monitoringExamId && (
                <span className="w-2 h-2 bg-success rounded-full ml-auto animate-pulse"></span>
              )}
            </button>
          ))}
        </div>

        {/* Main Content */}
        <div className="flex-1 p-8 overflow-y-auto max-h-[calc(100vh-65px)]">

          {/* ═══ EXAMS TAB ═══ */}
          {tab === "exams" && (
            <div className="max-w-5xl mx-auto">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-2xl font-serif font-bold text-primary">Exam Management</h2>
                  <p className="text-sm text-muted mt-1">Create and configure examinations</p>
                </div>
                <button onClick={() => setShowCreateExam(true)} className="btn-primary">+ Create Exam</button>
              </div>

              {/* Create Exam with Inline Questions */}
              {showCreateExam && (
                <div className="card p-6 mb-8 border-l-4 border-l-accent">
                  <h3 className="text-lg font-serif font-bold text-primary mb-6">Create New Exam</h3>
                  <form onSubmit={handleCreateExam}>
                    {/* Exam Details */}
                    <div className="grid grid-cols-2 gap-5 mb-8 pb-6 border-b border-border">
                      <div className="col-span-2">
                        <label className="text-sm font-medium text-primary mb-1 block">Exam Title</label>
                        <input value={examForm.exam_title} onChange={(e) => setExamForm({ ...examForm, exam_title: e.target.value })}
                          className="input-field" placeholder="e.g. DBMS Midterm" required />
                      </div>
                      <div>
                        <label className="text-sm font-medium text-primary mb-1 block">Duration (minutes)</label>
                        <input type="number" value={examForm.duration} onChange={(e) => setExamForm({ ...examForm, duration: parseInt(e.target.value) })}
                          className="input-field" required />
                      </div>
                      <div className="flex items-end">
                        <div className="bg-surfaceAlt rounded-lg px-4 py-2 border border-border w-full text-center">
                          <span className="text-xs text-muted block">Auto-calculated Marks</span>
                          <span className="text-lg font-bold text-primary">{examQuestions.reduce((s, q) => s + (q.marks || 1), 0)}</span>
                        </div>
                      </div>
                    </div>

                    {/* Questions Section */}
                    <div className="mb-6">
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="font-serif font-bold text-primary">Questions ({examQuestions.length})</h4>
                        <button type="button" onClick={addNewQuestion}
                          className="text-sm font-bold text-green-600 hover:text-green-700 flex items-center gap-1 px-3 py-1.5 rounded-md border border-green-300 bg-green-50 hover:bg-green-100 transition-colors">
                          + Add Question
                        </button>
                      </div>

                      <div className="space-y-6">
                        {examQuestions.map((eq, qi) => (
                          <div key={qi} className="bg-surfaceAlt rounded-lg border border-border p-5">
                            <div className="flex items-center justify-between mb-4">
                              <span className="text-xs font-bold text-primary bg-primary/10 px-2 py-1 rounded">Q{qi + 1}</span>
                              {examQuestions.length > 1 && (
                                <button type="button" onClick={() => removeExamQuestion(qi)}
                                  className="text-xs text-red-500 hover:text-red-700 font-bold">✕ Remove</button>
                              )}
                            </div>
                            <div className="mb-4">
                              <textarea value={eq.questionText} onChange={(e) => updateExamQuestion(qi, "questionText", e.target.value)}
                                className="input-field min-h-[70px]" placeholder="Enter question text..." required />
                            </div>
                            <div className="grid grid-cols-2 gap-3 mb-4">
                              {["A", "B", "C", "D"].map((letter, oi) => (
                                <input key={letter} value={eq.options[oi]}
                                  onChange={(e) => updateExamQuestionOption(qi, oi, e.target.value)}
                                  className="input-field text-sm" placeholder={`Option ${letter}`} required />
                              ))}
                            </div>
                            <div className="grid grid-cols-3 gap-3">
                              <div>
                                <label className="text-xs font-medium text-muted mb-1 block">Correct</label>
                                <select value={eq.correctAnswer} onChange={(e) => updateExamQuestion(qi, "correctAnswer", e.target.value)}
                                  className="input-field text-sm bg-surface">
                                  {["A", "B", "C", "D"].map((l) => <option key={l} value={l}>{l}</option>)}
                                </select>
                              </div>
                              <div>
                                <label className="text-xs font-medium text-muted mb-1 block">Difficulty</label>
                                <select value={eq.difficulty} onChange={(e) => updateExamQuestion(qi, "difficulty", e.target.value)}
                                  className="input-field text-sm bg-surface">
                                  <option value="Easy">Easy</option>
                                  <option value="Medium">Medium</option>
                                  <option value="Hard">Hard</option>
                                </select>
                              </div>
                              <div>
                                <label className="text-xs font-medium text-muted mb-1 block">Marks</label>
                                <input type="number" value={eq.marks} onChange={(e) => updateExamQuestion(qi, "marks", parseInt(e.target.value) || 1)}
                                  className="input-field text-sm bg-surface" min="1" />
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="flex gap-3 pt-4 border-t border-border">
                      <button type="submit" className="bg-green-600 hover:bg-green-700 text-white font-bold px-6 py-2.5 rounded-md transition-colors">
                        ✅ Create Exam with {examQuestions.length} Question{examQuestions.length > 1 ? "s" : ""}
                      </button>
                      <button type="button" onClick={() => { setShowCreateExam(false); setExamQuestions([{ questionText: "", options: ["", "", "", ""], correctAnswer: "A", difficulty: "Easy", marks: 1 }]); }}
                        className="btn-outline">Cancel</button>
                    </div>
                  </form>
                </div>
              )}

              {/* Exam List */}
              <div className="space-y-4">
                {exams.map((exam) => (
                  <div key={exam.id} className="card p-6">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-lg font-serif font-bold text-primary">{exam.exam_title}</h3>
                        <div className="flex items-center gap-4 mt-2 text-sm text-muted font-medium">
                          <span>{exam.duration} Minutes</span>
                          <span>•</span>
                          <span>{exam.question_count} Questions</span>
                          <span>•</span>
                          <span>{exam.student_count} Registered</span>
                          <span>•</span>
                          <span>{exam.total_marks} Marks</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`badge ${
                          exam.status === "live" ? "badge-green" :
                          exam.status === "ready" ? "badge-gold" :
                          exam.status === "completed" ? "badge-navy" :
                          "badge-navy"
                        }`}>{exam.status.toUpperCase()}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 mt-6 pt-4 border-t border-border">
                      <div className="flex-1"></div>

                      {exam.status === "draft" && (
                        <button onClick={() => handleStatusChange(exam.id, "ready")}
                          className="btn-outline text-sm py-1.5">
                          Mark Ready
                        </button>
                      )}
                      {exam.status === "ready" && (
                        <button onClick={() => handleStatusChange(exam.id, "live")}
                          className="btn-primary text-sm py-1.5 flex items-center gap-2">
                          <span className="w-2 h-2 bg-success rounded-full"></span>
                          Start Exam Live
                        </button>
                      )}
                      {exam.status === "live" && (
                        <>
                          <button onClick={() => startMonitoring(exam.id)}
                            className="btn-accent text-sm py-1.5 flex items-center gap-2">
                            👁️ Monitor Active Session
                          </button>
                          <button onClick={() => handleStatusChange(exam.id, "completed")}
                            className="btn-outline text-danger border-danger/30 hover:bg-red-50 text-sm py-1.5">
                            End Exam
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}


          {/* ═══ LIVE MONITOR TAB ═══ */}
          {tab === "monitor" && (
            <div className="max-w-6xl mx-auto">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-2xl font-serif font-bold text-primary">Live Monitoring Station</h2>
                  {monitoringExamId && (
                    <p className="text-sm text-muted mt-1 font-medium">
                      Tracking Exam #{monitoringExamId} • {students.length} student(s) actively connected
                    </p>
                  )}
                </div>
                {monitoringExamId && (
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-green-50 text-success rounded-md border border-green-200">
                    <span className="w-2 h-2 bg-success rounded-full animate-pulse"></span>
                    <span className="text-sm font-bold tracking-wider uppercase">Live</span>
                  </div>
                )}
              </div>

              {!monitoringExamId ? (
                <div className="card p-12 text-center">
                  <div className="w-16 h-16 bg-surfaceAlt rounded-full flex items-center justify-center mx-auto mb-4 text-2xl">👁️</div>
                  <p className="text-lg font-serif font-bold text-primary mb-2">No active session selected</p>
                  <p className="text-sm text-muted">Navigate to the Exams tab, ensure an exam is Live, and click "Monitor Active Session".</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
                  {/* Left Col: Students */}
                  <div className="xl:col-span-2 space-y-6">
                    <h3 className="text-lg font-serif font-bold text-primary border-b border-border pb-2">Active Candidates</h3>
                    {students.length === 0 ? (
                      <div className="card p-8 text-center text-muted border-dashed">
                        Waiting for candidates to join the exam room...
                      </div>
                    ) : (
                      students.map((student) => {
                        const sId = String(student.studentId || student.id);
                        return (
                        <div key={sId} className="card p-5">
                          <div className="flex items-center justify-between mb-4 border-b border-border pb-3">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white font-bold text-xs">
                                {student.name ? student.name.charAt(0) : "S"}
                              </div>
                              <span className="text-primary font-bold">{student.name || student.studentName || `Student #${sId}`}</span>
                            </div>
                            <span className="badge badge-navy font-mono">ID: {sId}</span>
                          </div>

                          <div className="grid grid-cols-2 gap-5">
                            {/* Camera Feed (snapshot) */}
                            <div className="bg-surfaceAlt rounded-lg overflow-hidden border border-border">
                              <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-surface">
                                <span className="text-xs font-semibold text-primary uppercase tracking-wide">📷 Identity Feed</span>
                              </div>
                              {cameraFrames[sId] ? (
                                <img src={cameraFrames[sId]} alt="camera" className="w-full aspect-video object-cover" />
                              ) : (
                                <div className="w-full aspect-video flex items-center justify-center text-muted text-sm bg-gray-50">No feed</div>
                              )}
                            </div>

                            {/* Screen Feed (snapshot) */}
                            <div className="bg-surfaceAlt rounded-lg overflow-hidden border border-border">
                              <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-surface">
                                <span className="text-xs font-semibold text-primary uppercase tracking-wide">🖥️ Workspace Feed</span>
                              </div>
                              {screenFrames[sId] ? (
                                <img src={screenFrames[sId]} alt="screen" className="w-full aspect-video object-cover" />
                              ) : (
                                <div className="w-full aspect-video flex items-center justify-center text-muted text-sm bg-gray-50">No feed</div>
                              )}
                            </div>
                          </div>

                          {/* WebRTC Live Video+Audio Streams */}
                          {rtcStreams[sId] && rtcStreams[sId].length > 0 && (
                            <div className="mt-4 pt-4 border-t border-border">
                              <div className="flex items-center gap-2 mb-3">
                                <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                                <span className="text-xs font-bold text-success uppercase tracking-widest">Live WebRTC Streams</span>
                              </div>
                              <div className="grid grid-cols-2 gap-4">
                                {rtcStreams[sId].map((stream, idx) => (
                                  <RTCVideo key={stream.id} stream={stream} label={idx === 0 ? "🎥 Live Camera + Audio" : "🖥️ Live Screen"} />
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      )})
                    )}
                  </div>

                  {/* Right Col: Timeline */}
                  <div className="xl:col-span-1">
                    <div className="card p-5 sticky top-8">
                      <h3 className="text-lg font-serif font-bold text-primary mb-4 border-b border-border pb-2">🚨 Incident Timeline</h3>
                      <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
                        {events.length === 0 ? (
                          <p className="text-sm text-muted text-center py-8">No incidents reported</p>
                        ) : (
                          events.map((event, i) => (
                            <div key={i} className={`p-3 rounded-md border text-sm ${getFlagColor(event.type)}`}>
                              <div className="flex items-center gap-2 font-bold mb-1">
                                <span>⚠️ {event.type.replace(/_/g, " ")}</span>
                                {event.duration && <span className="font-normal opacity-80">({event.duration}s)</span>}
                              </div>
                              <div className="flex flex-col gap-1 text-xs opacity-90 font-medium">
                                <span>Candidate ID: {event.studentId}</span>
                                <span>Time: {new Date(event.timestamp).toLocaleTimeString()}</span>
                                {event.riskScore !== undefined && (
                                  <span className="font-bold text-danger mt-1 pt-1 border-t border-current/20">System Risk Score: {event.riskScore}</span>
                                )}
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Helper component: renders a live WebRTC MediaStream as a video element
function RTCVideo({ stream, label }) {
  const videoRef = useRef(null);

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  return (
    <div className="bg-surfaceAlt rounded-lg overflow-hidden border-2 border-success/30">
      <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-surface">
        <span className="w-2 h-2 bg-success rounded-full animate-pulse"></span>
        <span className="text-xs font-semibold text-success uppercase tracking-wide">{label}</span>
      </div>
      <video
        ref={videoRef}
        autoPlay
        playsInline
        className="w-full aspect-video object-cover bg-black"
      />
    </div>
  );
}