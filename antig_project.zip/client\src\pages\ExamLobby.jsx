// client/src/pages/ExamLobby.jsx
import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import useStore from "../store/useStore";
import { getExam, startExamApi } from "../services/api";
import socket from "../services/socket";

export default function ExamLobby() {
  const navigate = useNavigate();
  const { examId } = useParams();
  const user = useStore((s) => s.user);

  const [exam, setExam] = useState(null);
  const [camera, setCamera] = useState(false);
  const [mic, setMic] = useState(false);
  const [screen, setScreen] = useState(false);
  const [accepted, setAccepted] = useState(false);
  const [examLive, setExamLive] = useState(false);
  const [screenStream, setScreenStream] = useState(null);
  const [loading, setLoading] = useState(false);

  const loadExam = async () => {
    try {
      const res = await getExam(examId);
      setExam(res.data);
      if (res.data.status === "live") setExamLive(true);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    loadExam();

    socket.on("exam:started", (data) => {
      if (String(data.examId) === String(examId)) {
        setExamLive(true);
      }
    });

    return () => {
      socket.off("exam:started");
    };
  }, [examId]);

  async function checkCamera() {
    try {
      await navigator.mediaDevices.getUserMedia({ video: true });
      setCamera(true);
    } catch {
      alert("Camera access denied");
    }
  }

  async function checkMic() {
    try {
      await navigator.mediaDevices.getUserMedia({ audio: true });
      setMic(true);
    } catch {
      alert("Microphone access denied");
    }
  }

  async function checkScreen() {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
      const track = stream.getVideoTracks()[0];
      const settings = track.getSettings();

      if (settings.displaySurface !== "monitor") {
        alert("❌ You MUST select Entire Screen");
        track.stop();
        setScreen(false);
        return;
      }

      setScreen(true);
      setScreenStream(stream);
    } catch {
      alert("Screen share denied");
    }
  }

  const allReady = camera && mic && screen && accepted && examLive;

  const handleEnterExam = async () => {
    setLoading(true);
    try {
      await startExamApi(examId);

      socket.emit("exam:join", {
        studentId: String(user.id),
        examId: String(examId),
        studentName: user.name,
      });

      window.__screenStream = screenStream;

      navigate(`/exam/take/${examId}`);
    } catch (err) {
      alert(err.response?.data?.error || "Failed to start exam");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-lg">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-surface border-2 border-accent shadow-sm mb-4">
            <span className="text-3xl">🛡️</span>
          </div>
          <h1 className="text-3xl font-serif font-bold text-primary">System Verification</h1>
          {exam && <p className="text-muted mt-2 font-medium">{exam.exam_title}</p>}
        </div>

        <div className="card p-8">
          {/* Status Checks */}
          <div className="space-y-3 mb-8">
            <StatusRow label="Camera Access" status={camera} />
            <StatusRow label="Microphone Access" status={mic} />
            <StatusRow label="Screen Share Validation" status={screen} />
            <StatusRow label="Proctor Authorization" status={examLive} statusText={examLive ? "Live" : "Waiting for Proctor"} />
          </div>

          {/* Permission Buttons */}
          <div className="space-y-3 mb-8 border-t border-border pt-6">
            {!camera && (
              <button onClick={checkCamera} className="btn-outline w-full py-2.5 font-bold">
                📷 Grant Camera Access
              </button>
            )}
            {!mic && camera && (
              <button onClick={checkMic} className="btn-outline w-full py-2.5 font-bold">
                🎤 Grant Microphone Access
              </button>
            )}
            {!screen && mic && (
              <button onClick={checkScreen} className="btn-outline w-full py-2.5 font-bold">
                🖥️ Share Entire Screen
              </button>
            )}
          </div>

          {/* Rules */}
          <div className="bg-surfaceAlt border border-border rounded-lg p-5 mb-6">
            <h3 className="text-sm font-bold text-primary mb-3 uppercase tracking-wide">📋 Integrity Protocol</h3>
            <ul className="text-sm text-muted space-y-2 font-medium">
              <li>• Your workspace and screen will be continuously monitored.</li>
              <li>• Artificial Intelligence will detect gaze anomalies and missing faces.</li>
              <li>• Navigating away from the active tab will be flagged immediately.</li>
              <li>• Clipboard operations (Copy/Paste) are strictly prohibited.</li>
            </ul>
          </div>

          <label className="flex items-start gap-3 text-sm text-primary mb-6 cursor-pointer bg-surface p-4 rounded-md border border-border hover:bg-surfaceAlt transition-colors">
            <input
              type="checkbox"
              checked={accepted}
              onChange={() => setAccepted(!accepted)}
              className="mt-1 h-4 w-4 text-accent rounded border-gray-300 focus:ring-accent"
            />
            <span className="font-medium">I acknowledge and agree to adhere strictly to the academic integrity protocols.</span>
          </label>

          {/* Waiting indicator */}
          {!examLive && (
            <div className="flex items-center justify-center gap-2 py-4 rounded-md bg-yellow-50 border border-yellow-200 text-yellow-700 text-sm mb-4 font-bold shadow-inner">
              <span className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse"></span>
              Awaiting Proctor Authorization...
            </div>
          )}

          <button
            onClick={handleEnterExam}
            disabled={!allReady || loading}
            className={`w-full py-4 text-base font-bold rounded-md transition-all text-lg tracking-wide ${
              !allReady || loading 
                ? "bg-gray-300 text-gray-500 cursor-not-allowed border border-gray-400" 
                : "bg-green-600 text-white hover:bg-green-700 shadow-elevated"
            }`}
          >
            {loading ? "Initializing..." : "🚀 Begin Examination"}
          </button>
        </div>
      </div>
    </div>
  );
}

function StatusRow({ label, status, statusText }) {
  return (
    <div className="flex items-center justify-between bg-surfaceAlt border border-border px-4 py-3 rounded-md">
      <span className="text-sm font-medium text-primary">{label}</span>
      <span className={`flex items-center gap-2 text-sm font-bold ${status ? "text-success" : "text-muted"}`}>
        <span className={`w-2 h-2 rounded-full ${status ? "bg-success" : "bg-gray-400"}`}></span>
        {statusText || (status ? "Verified" : "Pending")}
      </span>
    </div>
  );
}