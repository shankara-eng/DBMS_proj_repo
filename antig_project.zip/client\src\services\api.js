// client/src/services/api.js
import axios from "axios";

const API_BASE = "http://localhost:5000/api";

const api = axios.create({
  baseURL: API_BASE,
});

// Attach token to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Auth
export const loginUser = (data) => api.post("/auth/login", data);
export const registerUser = (data) => api.post("/auth/register", data);
export const getMe = () => api.get("/auth/me");

// Exams
export const getExams = () => api.get("/exams");
export const getExam = (id) => api.get(`/exams/${id}`);
export const createExam = (data) => api.post("/exams", data);
export const updateExamStatus = (id, status) => api.patch(`/exams/${id}/status`, { status });
export const addQuestionsToExam = (id, question_ids) => api.post(`/exams/${id}/questions`, { question_ids });
export const getExamQuestions = (id) => api.get(`/exams/${id}/questions`);
export const registerForExam = (id) => api.post(`/exams/${id}/register`);
export const startExamApi = (id) => api.post(`/exams/${id}/start`);
export const getMyExams = () => api.get("/exams/my-exams");
export const getExamStudents = (id) => api.get(`/exams/${id}/students`);

// Questions
export const getQuestions = () => api.get("/questions");
export const createQuestion = (data) => api.post("/questions", data);
export const updateQuestion = (id, data) => api.put(`/questions/${id}`, data);
export const deleteQuestion = (id) => api.delete(`/questions/${id}`);

// Answers
export const submitAnswer = (data) => api.post("/answers", data);
export const getMyAnswers = (examId) => api.get(`/answers/${examId}`);
export const submitExam = (examId) => api.post(`/answers/${examId}/submit`);

// Scores
export const getScores = () => api.get("/scores");

// Sessions
export const getLiveSession = (studentId) => api.get(`/sessions/${studentId}`);

export default api;
