import pool from "../config/postgres.js";

// ✅ calculate score
export const calculateScore = async (req, res) => {

  try {

    const { student_id, exam_id } = req.body;

    // get answers + correct answers
    const result = await pool.query(
      `
      SELECT
        sa.selected_answer,
        q.correct_answer
      FROM student_answers sa
      JOIN questions q
      ON sa.question_id = q.id
      WHERE sa.student_id = $1
      `,
      [student_id]
    );

    let score = 0;

    result.rows.forEach((row) => {

      if (
        row.selected_answer === row.correct_answer
      ) {
        score++;
      }

    });

    // save score
    const savedScore = await pool.query(
      `
      INSERT INTO scores
      (
        student_id,
        exam_id,
        score
      )
      VALUES ($1, $2, $3)
      RETURNING *
      `,
      [student_id, exam_id, score]
    );

    res.json(savedScore.rows[0]);

  } catch (err) {

    console.error(err);

    res.status(500).json({
      error: "Failed to calculate score",
    });
  }
};

// ✅ get scores
export const getScores = async (req, res) => {

  try {

    const result = await pool.query(
      `
      SELECT * FROM scores
      ORDER BY id DESC
      `
    );

    res.json(result.rows);

  } catch (err) {

    console.error(err);

    res.status(500).json({
      error: "Failed to fetch scores",
    });
  }
};