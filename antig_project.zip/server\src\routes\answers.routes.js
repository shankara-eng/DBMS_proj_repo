// server/src/routes/answers.routes.js
import express from "express";
import { authenticateToken } from "../middleware/auth.js";
import { submitAnswer, getMyAnswers, submitExam } from "../controllers/answers.controller.js";

const router = express.Router();

router.post("/", authenticateToken, submitAnswer);
router.get("/:examId", authenticateToken, getMyAnswers);
router.post("/:examId/submit", authenticateToken, submitExam);

export default router;