import express from "express";

import {
  calculateScore,
  getScores
} from "../controllers/scores.controller.js";

const router = express.Router();

router.post("/calculate", calculateScore);

router.get("/", getScores);

export default router;