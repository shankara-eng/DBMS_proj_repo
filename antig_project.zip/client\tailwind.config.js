/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: '#FAF9F6', // Soft beige/paper
        surface: '#FFFFFF',
        surfaceAlt: '#F4F1EA',
        primary: '#1C1C2E', // Dark Navy
        primaryHover: '#2A2A40',
        accent: '#C5A059', // Gold/Brass
        accentHover: '#B8860B',
        border: '#E5E2DB',
        muted: '#6B7280',
        danger: '#DC2626',
        success: '#059669',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        serif: ['Playfair Display', 'Georgia', 'serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      boxShadow: {
        'soft': '0 4px 20px -2px rgba(28, 28, 46, 0.05)',
        'elevated': '0 10px 30px -5px rgba(28, 28, 46, 0.1)',
      }
    },
  },
  plugins: [],
}
