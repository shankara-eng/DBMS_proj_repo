// server/src/controllers/exams.controller.js
import pool from "../config/postgres.js";

// ✅ Create exam (proctor/admin)
export const createExam = async (req, res) => {
  try {
    const { exam_title, duration, total_marks, start_time, end_time, proctoring_settings } = req.body;

    const result = await pool.query(
      `INSERT INTO exams (exam_title, duration, total_marks, start_time, end_time, status, proctoring_settings, created_by)
       VALUES ($1, $2, $3, $4, $5, 'draft', $6, $7)
       RETURNING *`,
      [exam_title, duration, total_marks || 0, start_time, end_time, JSON.stringify(proctoring_settings || {}), req.user.id]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create exam" });
  }
};

// ✅ Get all exams
export const getExams = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT e.*, u.name as creator_name,
       (SELECT COUNT(*) FROM exam_questions eq WHERE eq.exam_id = e.id) as question_count,
       (SELECT COUNT(*) FROM exam_registrations er WHERE er.exam_id = e.id) as student_count
       FROM exams e
       LEFT JOIN users u ON e.created_by = u.id
       ORDER BY e.id DESC`
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch exams" });
  }
};

// ✅ Get single exam
export const getExam = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT e.*, u.name as creator_name FROM exams e
       LEFT JOIN users u ON e.created_by = u.id
       WHERE e.id = $1`,
      [req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: "Exam not found" });
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch exam" });
  }
};

// ✅ Update exam status (start/stop)
export const updateExamStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const result = await pool.query(
      `UPDATE exams SET status = $1 WHERE id = $2 RETURNING *`,
      [status, req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: "Exam not found" });
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update exam status" });
  }
};

// ✅ Link questions to exam
export const addQuestionsToExam = async (req, res) => {
  try {
    const { question_ids } = req.body;
    const examId = req.params.id;

    // Clear existing
    await pool.query("DELETE FROM exam_questions WHERE exam_id = $1", [examId]);

    // Insert new links
    for (const qId of question_ids) {
      await pool.query(
        "INSERT INTO exam_questions (exam_id, question_id) VALUES ($1, $2)",
        [examId, qId]
      );
    }

    // Update total marks
    const marks = await pool.query(
      "SELECT COALESCE(SUM(q.marks), 0) as total FROM questions q JOIN exam_questions eq ON q.id = eq.question_id WHERE eq.exam_id = $1",
      [examId]
    );
    await pool.query("UPDATE exams SET total_marks = $1 WHERE id = $2", [marks.rows[0].total, examId]);

    res.json({ message: "Questions linked successfully", count: question_ids.length });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to link questions" });
  }
};

// ✅ Get exam questions (for student taking exam)
export const getExamQuestions = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT q.id, q.question_text, q.type, q.options, q.marks
       FROM questions q
       JOIN exam_questions eq ON q.id = eq.question_id
       WHERE eq.exam_id = $1
       ORDER BY eq.id`,
      [req.params.id]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch exam questions" });
  }
};

// ✅ Register student for exam
export const registerForExam = async (req, res) => {
  try {
    const result = await pool.query(
      `INSERT INTO exam_registrations (student_id, exam_id) VALUES ($1, $2)
       ON CONFLICT (student_id, exam_id) DO NOTHING
       RETURNING *`,
      [req.user.id, req.params.id]
    );
    if (result.rows.length === 0) {
      return res.json({ message: "Already registered" });
    }
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to register" });
  }
};

// ✅ Get student's exams (registered)
export const getMyExams = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT e.*, er.status as registration_status, er.risk_score, er.started_at, er.submitted_at
       FROM exams e
       JOIN exam_registrations er ON e.id = er.exam_id
       WHERE er.student_id = $1
       ORDER BY e.id DESC`,
      [req.user.id]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch registered exams" });
  }
};

// ✅ Start exam (student marks as in_progress)
export const startExam = async (req, res) => {
  try {
    // Check exam is live
    const exam = await pool.query("SELECT * FROM exams WHERE id = $1", [req.params.id]);
    if (exam.rows.length === 0) return res.status(404).json({ error: "Exam not found" });
    if (exam.rows[0].status !== "live") return res.status(400).json({ error: "Exam is not live yet" });

    const result = await pool.query(
      `UPDATE exam_registrations SET status = 'in_progress', started_at = NOW()
       WHERE student_id = $1 AND exam_id = $2
       RETURNING *`,
      [req.user.id, req.params.id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to start exam" });
  }
};

// ✅ Get registered students for an exam (proctor view)
export const getExamStudents = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT u.id, u.name, u.email, er.status, er.risk_score, er.started_at, er.submitted_at
       FROM exam_registrations er
       JOIN users u ON er.student_id = u.id
       WHERE er.exam_id = $1
       ORDER BY er.risk_score DESC`,
      [req.params.id]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch students" });
  }
};