import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import pool from './config/postgres.js';
import dotenv from 'dotenv';
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function runSchema() {
  try {
    const schemaSql = fs.readFileSync(path.join(__dirname, 'config', 'schema.sql'), 'utf-8');
    
    // Create DB if it doesn't exist? Well, let's assume proctor_system DB is already there or postgres user can create it, wait, pool connects to proctor_system.
    // Let's just execute the SQL on it.
    console.log("Applying schema...");
    await pool.query(schemaSql);
    console.log("Schema applied successfully.");
  } catch (err) {
    console.error("Error applying schema:", err);
  } finally {
    pool.end();
  }
}

runSchema();
