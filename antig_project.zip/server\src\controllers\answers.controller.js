// server/src/controllers/answers.controller.js
import pool from "../config/postgres.js";

// ✅ Submit / Update answer (upsert)
export const submitAnswer = async (req, res) => {
  try {
    const { exam_id, question_id, selected_answer } = req.body;
    const student_id = req.user.id;

    const result = await pool.query(
      `INSERT INTO student_answers (student_id, exam_id, question_id, selected_answer)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (student_id, exam_id, question_id)
       DO UPDATE SET selected_answer = $4, answered_at = NOW()
       RETURNING *`,
      [student_id, exam_id, question_id, selected_answer]
    );

    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to submit answer" });
  }
};

// ✅ Get student answers for an exam
export const getMyAnswers = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM student_answers WHERE student_id = $1 AND exam_id = $2`,
      [req.user.id, req.params.examId]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch answers" });
  }
};

// ✅ Submit exam (calculate score + update registration)
export const submitExam = async (req, res) => {
  try {
    const student_id = req.user.id;
    const exam_id = req.params.examId;

    // Calculate score
    const result = await pool.query(
      `SELECT sa.selected_answer, q.correct_answer, q.marks
       FROM student_answers sa
       JOIN questions q ON sa.question_id = q.id
       WHERE sa.student_id = $1 AND sa.exam_id = $2`,
      [student_id, exam_id]
    );

    let score = 0;
    let total = 0;
    result.rows.forEach((row) => {
      total += row.marks;
      if (row.selected_answer === row.correct_answer) {
        score += row.marks;
      }
    });

    const percentage = total > 0 ? ((score / total) * 100).toFixed(2) : 0;

    // Save score
    await pool.query(
      `INSERT INTO scores (student_id, exam_id, score, total, percentage)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (student_id, exam_id) DO UPDATE SET score = $3, total = $4, percentage = $5`,
      [student_id, exam_id, score, total, percentage]
    );

    // Update registration status
    await pool.query(
      `UPDATE exam_registrations SET status = 'submitted', submitted_at = NOW()
       WHERE student_id = $1 AND exam_id = $2`,
      [student_id, exam_id]
    );

    res.json({ score, total, percentage: parseFloat(percentage) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to submit exam" });
  }
};