// client/src/pages/LoginPage.jsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import useStore from "../store/useStore";
import { loginUser, registerUser } from "../services/api";

export default function LoginPage() {
  const navigate = useNavigate();
  const setAuth = useStore((s) => s.setAuth);

  const [isRegister, setIsRegister] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    role: "student",
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = isRegister
        ? await registerUser(form)
        : await loginUser({ email: form.email, password: form.password });

      const { token, user } = res.data;
      setAuth(user, token);

      if (user.role === "student") navigate("/student");
      else if (user.role === "proctor") navigate("/proctor");
      else navigate("/admin");
    } catch (err) {
      setError(err.response?.data?.error || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4 relative">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="flex flex-col items-center justify-center gap-3 mb-8">
          <div className="w-12 h-12 rounded bg-primary flex items-center justify-center text-accent font-serif font-bold text-2xl border border-accent/20">P</div>
          <span className="text-2xl font-serif font-bold text-primary">ProctorAI</span>
        </div>

        {/* Card */}
        <div className="card p-8">
          <h2 className="text-2xl font-serif font-bold text-primary text-center mb-2">
            {isRegister ? "Create Account" : "Welcome Back"}
          </h2>
          <p className="text-muted text-center text-sm mb-6 font-sans">
            {isRegister ? "Register to access the portal" : "Sign in to your dashboard"}
          </p>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md text-sm mb-4">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {isRegister && (
              <div>
                <label className="block text-sm font-medium text-primary mb-1">Full Name</label>
                <input
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  className="input-field"
                  placeholder="John Doe"
                  required
                />
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-primary mb-1">Email</label>
              <input
                name="email"
                type="email"
                value={form.email}
                onChange={handleChange}
                className="input-field"
                placeholder="you@university.edu"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-primary mb-1">Password</label>
              <input
                name="password"
                type="password"
                value={form.password}
                onChange={handleChange}
                className="input-field"
                placeholder="••••••••"
                required
              />
            </div>

            {isRegister && (
              <div>
                <label className="block text-sm font-medium text-primary mb-1">Role</label>
                <select
                  name="role"
                  value={form.role}
                  onChange={handleChange}
                  className="input-field"
                >
                  <option value="student">Student</option>
                  <option value="proctor">Faculty / Proctor</option>
                </select>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full py-2.5 text-base mt-2"
            >
              {loading ? "Please wait..." : isRegister ? "Create Account" : "Sign In"}
            </button>
          </form>

          {/* Quick login buttons */}
          {!isRegister && (
            <div className="mt-6 pt-6 border-t border-border">
              <p className="text-xs text-muted text-center mb-3 uppercase tracking-wider font-semibold">Quick Demo Login</p>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setForm({ ...form, email: "student@proctor.com", password: "student123" })}
                  className="btn-outline text-xs py-2"
                >
                  Demo Student
                </button>
                <button
                  onClick={() => setForm({ ...form, email: "proctor@proctor.com", password: "proctor123" })}
                  className="btn-outline text-xs py-2"
                >
                  Demo Proctor
                </button>
              </div>
            </div>
          )}

          <p className="text-center text-sm text-muted mt-6">
            {isRegister ? "Already have an account?" : "Don't have an account?"}{" "}
            <button
              onClick={() => { setIsRegister(!isRegister); setError(""); }}
              className="text-primary hover:text-accent font-semibold transition-colors"
            >
              {isRegister ? "Sign In" : "Register"}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
