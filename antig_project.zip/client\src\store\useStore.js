// client/src/store/useStore.js
import { create } from "zustand";

const useStore = create((set, get) => ({
  // Auth
  user: JSON.parse(localStorage.getItem("user") || "null"),
  token: localStorage.getItem("token") || null,

  setAuth: (user, token) => {
    localStorage.setItem("user", JSON.stringify(user));
    localStorage.setItem("token", token);
    set({ user, token });
  },

  logout: () => {
    localStorage.removeItem("user");
    localStorage.removeItem("token");
    set({ user: null, token: null });
  },

  // Exam state
  currentExamId: null,
  examStatus: null, // 'waiting' | 'live' | 'submitted'
  setCurrentExam: (examId, status) => set({ currentExamId: examId, examStatus: status }),

  // Proctoring flags
  flags: [],
  riskScore: 0,
  riskLevel: "LOW",
  latestFlag: null,
  showFlagAlert: false,

  addFlag: (flag) =>
    set((state) => {
      let scoreIncrease = 0;
      if (flag.type === "NO_FACE") scoreIncrease = 5;
      if (flag.type === "MULTIPLE_FACE") scoreIncrease = 10;
      if (flag.type === "LOOKING_AWAY") scoreIncrease = 3;
      if (flag.type === "TAB_SWITCH") scoreIncrease = 15;
      if (flag.type === "TAB_SWITCH_ONGOING") scoreIncrease = 2;
      if (flag.type === "TAB_SWITCH_DURATION") scoreIncrease = flag.duration || 4;

      const newScore = state.riskScore + scoreIncrease;

      let level = "LOW";
      if (newScore > 20) level = "MEDIUM";
      if (newScore > 40) level = "HIGH";
      if (newScore > 70) level = "CRITICAL";

      return {
        flags: [...state.flags, flag],
        riskScore: newScore,
        riskLevel: level,
        latestFlag: flag,
        showFlagAlert: true,
      };
    }),

  dismissFlagAlert: () => set({ showFlagAlert: false }),

  resetProctoring: () => set({
    flags: [],
    riskScore: 0,
    riskLevel: "LOW",
    latestFlag: null,
    showFlagAlert: false,
    currentExamId: null,
    examStatus: null,
  }),
}));

export default useStore;