// server/src/models/Event.js
import mongoose from "mongoose";

const eventSchema = new mongoose.Schema({
  studentId: { type: String, required: true, index: true },
  examId: { type: String, required: true, index: true },
  type: { type: String, required: true },
  confidence: Number,
  duration: Number,
  details: mongoose.Schema.Types.Mixed,
  timestamp: { type: Number, default: Date.now },
}, { timestamps: true });

export default mongoose.model("Event", eventSchema);