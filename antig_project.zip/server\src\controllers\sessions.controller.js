import {
  getSession
} from "../utils/sessionManager.js";

// ✅ get live Redis session
export const getLiveSession = async (
  req,
  res
) => {

  try {

    const { studentId } = req.params;

    const session = await getSession(
      studentId
    );

    res.json(session);

  } catch (err) {

    console.error(err);

    res.status(500).json({
      error: "Failed to fetch session",
    });
  }
};