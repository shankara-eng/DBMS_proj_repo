import express from "express";

import {
  getLiveSession
} from "../controllers/sessions.controller.js";

const router = express.Router();

router.get("/:studentId", getLiveSession);

export default router;