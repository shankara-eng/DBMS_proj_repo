// server/src/routes/auth.routes.js
import express from "express";
import { login, register, getMe } from "../controllers/auth.controller.js";
import { authenticateToken } from "../middleware/auth.js";

const router = express.Router();

router.post("/login", login);
router.post("/register", register);
router.get("/me", authenticateToken, getMe);

export default router;
