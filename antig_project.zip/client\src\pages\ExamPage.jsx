// client/src/pages/ExamPage.jsx
import { useEffect, useState, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import useStore from "../store/useStore";
import { getExamQuestions, submitAnswer, submitExam, getMyAnswers } from "../services/api";
import WebcamFeed from "../components/WebcamFeed";
import socket from "../services/socket";

export default function ExamPage() {
  const { examId } = useParams();
  const navigate = useNavigate();
  const user = useStore((s) => s.user);
  const { flags, riskScore, riskLevel, latestFlag, showFlagAlert, addFlag, dismissFlagAlert, resetProctoring } = useStore();

  const [questions, setQuestions] = useState([]);
  const [currentQ, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState({});
  const [timeLeft, setTimeLeft] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const [result, setResult] = useState(null);
  const [showSubmitConfirm, setShowSubmitConfirm] = useState(false);

  const tabStartTime = useRef(null);
  const intervalRef = useRef(null);

  // Single shared camera+audio stream for both WebcamFeed and WebRTC
  const [sharedCameraStream, setSharedCameraStream] = useState(null);

  useEffect(() => {
    let stream;
    navigator.mediaDevices.getUserMedia({ video: true, audio: true })
      .then((s) => {
        stream = s;
        setSharedCameraStream(s);
        console.log("📹 Shared camera+audio stream created");
      })
      .catch((err) => console.error("Camera/mic error:", err));

    return () => {
      if (stream) stream.getTracks().forEach((t) => t.stop());
    };
  }, []);

  const loadQuestions = async () => {
    try {
      const res = await getExamQuestions(examId);
      setQuestions(res.data);
      setTimeLeft(res.data.length * 120);
    } catch (err) {
      console.error(err);
    }
  };

  const loadSavedAnswers = async () => {
    try {
      const res = await getMyAnswers(examId);
      const saved = {};
      res.data.forEach((a) => { saved[a.question_id] = a.selected_answer; });
      setAnswers(saved);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    loadQuestions();
    loadSavedAnswers();

    socket.emit("exam:join", {
      studentId: String(user.id),
      examId: String(examId),
      studentName: user.name,
    });

    socket.on("exam:ended", () => {
      handleSubmit();
    });

    return () => {
      socket.off("exam:ended");
      resetProctoring();
    };
  }, [examId, user.id, user.name, resetProctoring]);

  useEffect(() => {
    if (timeLeft === null || timeLeft <= 0 || submitted) return;
    const timer = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) { handleSubmit(); return 0; }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [timeLeft, submitted]);

  useEffect(() => {
    function handleVisibilityChange() {
      if (document.visibilityState === "hidden") {
        tabStartTime.current = Date.now();
        intervalRef.current = setInterval(() => {
          const event = {
            studentId: String(user.id),
            examId: String(examId),
            type: "TAB_SWITCH_ONGOING",
            timestamp: Date.now(),
          };
          addFlag(event);
          socket.emit("flag:raised", event);
        }, 3000);
      } else if (document.visibilityState === "visible") {
        if (intervalRef.current) clearInterval(intervalRef.current);
        if (tabStartTime.current) {
          const duration = Date.now() - tabStartTime.current;
          const event = {
            studentId: String(user.id),
            examId: String(examId),
            type: "TAB_SWITCH_DURATION",
            duration: Math.floor(duration / 1000),
            timestamp: Date.now(),
          };
          addFlag(event);
          socket.emit("flag:raised", event);
        }
        tabStartTime.current = null;
      }
    }

    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  const latestProps = useRef({ user, examId });
  useEffect(() => {
    latestProps.current = { user, examId };
  }, [user, examId]);

  useEffect(() => {
    let stream = window.__screenStream;
    let localScreenInterval;

    const setupScreenShare = async () => {
      if (!stream) {
        try {
          stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
          window.__screenStream = stream;
        } catch (err) {
          console.error("Screen share missing");
          return;
        }
      }

      const video = document.createElement("video");
      video.srcObject = stream;
      video.muted = true;
      video.playsInline = true;

      video.onloadedmetadata = async () => {
        await video.play();
        localScreenInterval = setInterval(() => {
          if (video.videoWidth === 0 || video.videoHeight === 0) return;
          const canvas = document.createElement("canvas");
          canvas.width = 480;
          canvas.height = 270;
          const ctx = canvas.getContext("2d");
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const frame = canvas.toDataURL("image/jpeg", 0.25);
          const currentUser = latestProps.current.user;
          const currentExamId = latestProps.current.examId;
          const sId = currentUser ? currentUser.id : "unknown";
          socket.emit("screen:frame", { studentId: String(sId), examId: String(currentExamId), frame });
        }, 3000);
      };
    };

    setupScreenShare();

    return () => {
      if (localScreenInterval) clearInterval(localScreenInterval);
    };
  }, []);

  useEffect(() => {
    const prevent = (e) => e.preventDefault();
    const preventKeys = (e) => {
      if ((e.ctrlKey || e.metaKey) && ['c', 'v', 'x', 'a'].includes(e.key.toLowerCase())) {
        e.preventDefault();
      }
    };
    document.addEventListener("copy", prevent);
    document.addEventListener("paste", prevent);
    document.addEventListener("cut", prevent);
    document.addEventListener("contextmenu", prevent);
    document.addEventListener("keydown", preventKeys);
    return () => {
      document.removeEventListener("copy", prevent);
      document.removeEventListener("paste", prevent);
      document.removeEventListener("cut", prevent);
      document.removeEventListener("contextmenu", prevent);
      document.removeEventListener("keydown", preventKeys);
    };
  }, []);

  // ============ WebRTC: Smooth live video+audio to proctor ============
  const peerConnectionRef = useRef(null);

  useEffect(() => {
    const setupWebRTC = async () => {
      try {
        // Close any existing connection
        if (peerConnectionRef.current) {
          peerConnectionRef.current.close();
          peerConnectionRef.current = null;
        }

        const pc = new RTCPeerConnection({
          iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
        });
        peerConnectionRef.current = pc;

        // Reuse the shared camera+audio stream (same one WebcamFeed uses)
        if (sharedCameraStream) {
          sharedCameraStream.getTracks().forEach((track) => {
            pc.addTrack(track, sharedCameraStream);
          });
        }

        // Add screen share tracks if available
        const screenStream = window.__screenStream;
        if (screenStream) {
          screenStream.getVideoTracks().forEach((track) => {
            pc.addTrack(track, screenStream);
          });
        }

        // Send ICE candidates to proctor via server
        pc.onicecandidate = (event) => {
          if (event.candidate) {
            socket.emit("webrtc:ice-candidate", {
              studentId: String(user.id),
              examId: String(examId),
              candidate: event.candidate,
              target: "proctor",
            });
          }
        };

        // Create and send SDP offer
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        socket.emit("webrtc:offer", {
          studentId: String(user.id),
          examId: String(examId),
          offer,
        });

        console.log("📡 WebRTC offer sent to proctor");
      } catch (err) {
        console.error("WebRTC setup error:", err);
      }
    };

    // Handle answer from proctor
    const handleAnswer = async (data) => {
      const pc = peerConnectionRef.current;
      if (pc && data.answer) {
        try {
          await pc.setRemoteDescription(new RTCSessionDescription(data.answer));
          console.log("✅ WebRTC answer received, connection established");
        } catch (err) {
          console.error("Failed to set remote description:", err);
        }
      }
    };

    // Handle ICE candidates from proctor
    const handleIceCandidate = async (data) => {
      const pc = peerConnectionRef.current;
      if (pc && data.candidate) {
        try {
          await pc.addIceCandidate(new RTCIceCandidate(data.candidate));
        } catch (err) {
          console.error("ICE candidate error:", err);
        }
      }
    };

    // Listen for proctor ready signal, then start WebRTC
    socket.on("proctor:ready", () => {
      console.log("🟢 Proctor is ready, initiating WebRTC...");
      // Small delay to let screen share finish setup
      setTimeout(setupWebRTC, 1500);
    });

    socket.on("webrtc:answer", handleAnswer);
    socket.on("webrtc:ice-candidate", handleIceCandidate);

    return () => {
      socket.off("proctor:ready");
      socket.off("webrtc:answer");
      socket.off("webrtc:ice-candidate");
      if (peerConnectionRef.current) {
        peerConnectionRef.current.close();
        peerConnectionRef.current = null;
      }
    };
  }, [examId, user.id, sharedCameraStream]);

  const handleAnswer = async (questionId, answer) => {
    setAnswers({ ...answers, [questionId]: answer });
    try {
      await submitAnswer({ exam_id: parseInt(examId), question_id: questionId, selected_answer: answer });
    } catch (err) {
      console.error(err);
    }
  };

  const handleSubmit = async () => {
    if (submitted) return;
    setSubmitted(true);
    try {
      const res = await submitExam(examId);
      setResult(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const formatTime = (s) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, "0")}`;
  };

  const getRiskColor = () => {
    if (riskLevel === "CRITICAL") return "text-red-700";
    if (riskLevel === "HIGH") return "text-red-600";
    if (riskLevel === "MEDIUM") return "text-yellow-600";
    return "text-green-700";
  };

  if (submitted && result) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="card p-10 max-w-md text-center">
          <div className="text-5xl mb-6">✅</div>
          <h1 className="text-3xl font-serif font-bold text-primary mb-2">Assessment Complete</h1>
          <p className="text-muted text-sm mb-6">Your answers have been successfully recorded and graded.</p>
          <div className="bg-surfaceAlt border border-border rounded-xl p-8 my-6">
            <div className="text-5xl font-bold text-primary font-serif">{result.score}<span className="text-2xl text-muted">/{result.total}</span></div>
            <div className="text-lg text-accent font-bold mt-2 uppercase tracking-wide">{result.percentage}% SCORE</div>
          </div>
          <button onClick={() => navigate("/student")} className="btn-primary w-full py-3">
            Return to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const q = questions[currentQ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Top Bar */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-border bg-surface shadow-sm z-10">
        <div className="flex items-center gap-3 bg-red-50 px-4 py-2 rounded-md border border-red-200">
          <span className="w-2.5 h-2.5 bg-danger rounded-full animate-pulse"></span>
          <span className="text-sm font-bold text-danger uppercase tracking-wider">Active Monitoring</span>
        </div>

        <div className="flex items-center gap-6">
          <div className="flex flex-col text-right">
            <span className="text-xs font-semibold text-muted uppercase">Risk Profile</span>
            <span className={`font-bold ${getRiskColor()}`}>
              Score: {riskScore} ({riskLevel})
            </span>
          </div>
          <div className={`flex flex-col text-right pl-6 border-l border-border ${timeLeft && timeLeft < 60 ? "text-danger animate-pulse" : "text-primary"}`}>
             <span className="text-xs font-semibold uppercase opacity-70">Time Remaining</span>
            <span className="text-xl font-mono font-bold">
              {timeLeft ? formatTime(timeLeft) : "--:--"}
            </span>
          </div>
        </div>
      </div>

      {/* Flag Alert Box */}
      {showFlagAlert && latestFlag && (
        <div className="mx-6 mt-6">
          <div className="bg-red-50 border-l-4 border-l-danger border border-red-200 rounded-md px-5 py-4 flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-4">
              <span className="text-danger text-xl">⚠️</span>
              <div>
                <span className="text-danger font-bold text-sm uppercase tracking-wide">{latestFlag.type.replace(/_/g, " ")}</span>
                <span className="text-red-700 text-sm ml-2 font-medium">Warning: Suspicious behavior detected.</span>
                {latestFlag.duration && <span className="text-red-600 text-sm ml-1 font-bold">({latestFlag.duration}s)</span>}
              </div>
            </div>
            <button onClick={dismissFlagAlert} className="text-danger hover:bg-red-100 font-bold text-xs px-3 py-1.5 rounded-md border border-red-200 transition-colors">
              ACKNOWLEDGE
            </button>
          </div>
        </div>
      )}

      <div className="flex flex-1 overflow-hidden">
        {/* Question Panel */}
        <div className="flex-1 p-8 overflow-y-auto">
          {q ? (
            <div className="max-w-3xl mx-auto mt-4">
              {/* Question Number */}
              <div className="flex items-center gap-3 mb-6">
                <span className="bg-primary text-white text-xs font-bold px-3 py-1 rounded-full">
                  QUESTION {currentQ + 1} OF {questions.length}
                </span>
                <span className="text-sm font-semibold text-muted">
                  {q.marks} Point{q.marks > 1 ? "s" : ""}
                </span>
              </div>

              {/* Question Text */}
              <div className="mb-8">
                <h2 className="text-2xl font-serif text-primary leading-relaxed font-bold">{q.question_text}</h2>
              </div>

              {/* Options */}
              <div className="space-y-4">
                {q.options && q.options.map((opt, i) => {
                  const letter = String.fromCharCode(65 + i);
                  const isSelected = answers[q.id] === letter;
                  return (
                    <button
                      key={i}
                      onClick={() => handleAnswer(q.id, letter)}
                      className={`w-full text-left px-6 py-5 rounded-lg border-2 transition-all ${
                        isSelected
                          ? "border-green-400 bg-green-50"
                          : "border-border bg-surface hover:border-green-300 hover:bg-green-50/30"
                      }`}
                    >
                      <div className="flex items-center">
                        <span className={`flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-full mr-4 text-sm font-bold border-2 ${
                          isSelected ? "bg-green-500 border-green-500 text-white" : "border-border text-muted bg-surfaceAlt"
                        }`}>
                          {letter}
                        </span>
                        <span className={`text-lg ${isSelected ? "text-green-800 font-semibold" : "text-primary"}`}>{opt}</span>
                        {isSelected && <span className="ml-auto text-green-500 text-lg">✓</span>}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Navigation */}
              <div className="flex items-center justify-between mt-12 pt-8 border-t border-border">
                <button
                  onClick={() => setCurrentQ(Math.max(0, currentQ - 1))}
                  disabled={currentQ === 0}
                  className="btn-outline font-bold disabled:opacity-30 disabled:hover:bg-transparent"
                >
                  ← Previous Question
                </button>

                {currentQ < questions.length - 1 ? (
                  <button
                    onClick={() => setCurrentQ(currentQ + 1)}
                    className="btn-primary font-bold px-8 py-3"
                  >
                    Next Question →
                  </button>
                ) : (
                  <button
                    onClick={() => setShowSubmitConfirm(true)}
                    className="bg-red-600 hover:bg-red-700 text-white font-bold px-8 py-3 rounded-md shadow-md transition-all border border-red-700"
                  >
                    📝 Submit Assessment
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-32 text-muted">
              <div className="w-8 h-8 border-4 border-border border-t-accent rounded-full animate-spin mb-4"></div>
              <p className="font-medium">Loading assessment material...</p>
            </div>
          )}
        </div>

        {/* Right Sidebar */}
        <div className="w-80 border-l border-border bg-surfaceAlt p-6 flex flex-col gap-6">
          
          {/* Webcam Box */}
          <div className="card overflow-hidden border border-border">
            <div className="bg-primary text-white text-xs font-bold uppercase tracking-wider py-2 px-4 flex items-center gap-2">
              <span className="w-2 h-2 bg-success rounded-full animate-pulse"></span>
              Identity Feed
            </div>
            <div className="p-2 bg-surface">
               <WebcamFeed compact examId={examId} stream={sharedCameraStream} />
            </div>
          </div>

          {/* Question Navigator */}
          <div className="card p-5 flex-1 border border-border bg-surface">
            <h3 className="text-xs font-bold text-primary uppercase tracking-widest mb-4 border-b border-border pb-2">Assessment Overview</h3>
            <div className="grid grid-cols-5 gap-2.5">
              {questions.map((q, i) => {
                const isAnswered = !!answers[q.id];
                const isCurrent = i === currentQ;
                return (
                  <button
                    key={q.id}
                    onClick={() => setCurrentQ(i)}
                    className={`w-9 h-9 rounded text-sm font-bold transition-all ${
                      isCurrent && isAnswered
                        ? "bg-green-500 text-white shadow-md ring-2 ring-green-300 transform scale-110"
                        : isCurrent
                        ? "bg-gray-400 text-white shadow-md transform scale-110"
                        : isAnswered
                        ? "bg-green-500 text-white"
                        : "bg-surfaceAlt text-muted border border-border hover:border-primary/30"
                    }`}
                  >
                    {i + 1}
                  </button>
                );
              })}
            </div>
            
            <div className="mt-6 pt-4 border-t border-border">
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium text-muted">Progress</span>
                <span className="font-bold text-primary">{Object.keys(answers).length} / {questions.length}</span>
              </div>
              <div className="w-full bg-border h-2 rounded-full mt-2 overflow-hidden">
                <div 
                  className="bg-accent h-full transition-all duration-300" 
                  style={{ width: `${(Object.keys(answers).length / questions.length) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Submit confirmation modal */}
      {showSubmitConfirm && (
        <div className="fixed inset-0 bg-primary/40 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="card p-8 max-w-md w-full shadow-elevated">
            <h3 className="text-2xl font-serif font-bold text-primary mb-3 text-center">Confirm Submission</h3>
            
            <div className="bg-surfaceAlt rounded-lg p-4 mb-6 border border-border">
              <p className="text-center text-primary font-medium">
                You have answered <span className="font-bold text-accent">{Object.keys(answers).length}</span> out of <span className="font-bold">{questions.length}</span> questions.
              </p>
              {Object.keys(answers).length < questions.length && (
                <p className="text-center text-danger text-sm font-bold mt-2">
                  Warning: You have unanswered questions!
                </p>
              )}
            </div>

            <p className="text-sm text-muted mb-8 text-center font-medium">
              Once submitted, you will not be able to return to the examination. Are you absolutely sure you want to conclude the assessment?
            </p>
            <div className="flex gap-4">
              <button onClick={() => setShowSubmitConfirm(false)} className="flex-1 btn-outline font-bold">
                Return to Exam
              </button>
              <button onClick={handleSubmit} className="flex-1 bg-danger hover:bg-red-700 text-white font-bold rounded-md transition-colors">
                Submit Finally
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}