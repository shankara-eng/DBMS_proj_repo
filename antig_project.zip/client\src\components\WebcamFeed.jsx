// client/src/components/WebcamFeed.jsx
import { useEffect, useRef } from "react";
import * as faceapi from "face-api.js";
import useStore from "../store/useStore";
import socket from "../services/socket";

// Accepts an optional `stream` prop. If provided, uses that stream instead of creating its own.
export default function WebcamFeed({ compact = false, examId, stream: externalStream }) {
  const videoRef = useRef();
  const user = useStore((s) => s.user);
  const addFlag = useStore((s) => s.addFlag);
  const noFaceCount = useRef(0);
  const modelsLoaded = useRef(false);

  const latestProps = useRef({ user, examId });
  useEffect(() => {
    latestProps.current = { user, examId };
  }, [user, examId]);

  function triggerAlert(type) {
    const event = {
      studentId: String(latestProps.current.user?.id || "unknown"),
      examId: String(latestProps.current.examId || "unknown"),
      type,
      timestamp: Date.now(),
    };
    addFlag(event);
    socket.emit("flag:raised", event);
  }

  async function loadModels() {
    if (modelsLoaded.current) return;
    const MODEL_URL = "/models";
    try {
      await faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL);
      modelsLoaded.current = true;
      console.log("✅ Face detection models loaded");
    } catch (err) {
      console.warn("⚠️ Failed to load face models:", err);
    }
  }

  // Attach stream to video element
  useEffect(() => {
    if (externalStream && videoRef.current) {
      videoRef.current.srcObject = externalStream;
    } else if (!externalStream) {
      // Fallback: create own stream if none provided
      navigator.mediaDevices.getUserMedia({ video: true })
        .then((s) => { if (videoRef.current) videoRef.current.srcObject = s; })
        .catch((err) => console.error("Camera error:", err));
    }

    loadModels();

    return () => {
      // Only stop tracks if we created our own stream
      if (!externalStream && videoRef.current?.srcObject) {
        videoRef.current.srcObject.getTracks().forEach((t) => t.stop());
      }
    };
  }, [externalStream]);

  // Frame capture loop - ALWAYS sends frames to proctor
  useEffect(() => {
    const frameInterval = setInterval(() => {
      if (
        !videoRef.current ||
        videoRef.current.readyState !== 4 ||
        !videoRef.current.videoWidth ||
        !videoRef.current.videoHeight
      ) {
        return;
      }

      try {
        const canvas = document.createElement("canvas");
        canvas.width = 240;
        canvas.height = 180;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        const frame = canvas.toDataURL("image/jpeg", 0.25);

        const currentUser = latestProps.current.user;
        const currentExamId = latestProps.current.examId;
        const sId = currentUser ? currentUser.id : "unknown";

        socket.emit("camera:frame", {
          studentId: String(sId),
          examId: String(currentExamId || "unknown"),
          frame,
        });
      } catch (err) {
        console.error("Frame capture error:", err);
      }
    }, 3000);

    return () => clearInterval(frameInterval);
  }, []);

  // AI Detection loop - only runs when face-api models are loaded
  useEffect(() => {
    const detectionInterval = setInterval(async () => {
      if (
        !videoRef.current ||
        videoRef.current.readyState !== 4 ||
        !videoRef.current.videoWidth ||
        !videoRef.current.videoHeight ||
        !modelsLoaded.current
      ) {
        return;
      }

      try {
        const detections = await faceapi.detectAllFaces(
          videoRef.current,
          new faceapi.TinyFaceDetectorOptions()
        );

        if (detections.length === 0) {
          noFaceCount.current++;
          if (noFaceCount.current >= 2) {
            triggerAlert("NO_FACE");
            noFaceCount.current = 0;
          }
        } else {
          noFaceCount.current = 0;
        }

        if (detections.length > 1) {
          triggerAlert("MULTIPLE_FACE");
        }

        if (detections.length === 1) {
          const box = detections[0].box;
          const centerX = box.x + box.width / 2;
          const frameCenter = videoRef.current.videoWidth / 2;
          const diff = Math.abs(centerX - frameCenter);
          if (diff > 120) {
            triggerAlert("LOOKING_AWAY");
          }
        }
      } catch (err) {
        // Silently ignore detection errors
      }
    }, 5000);

    return () => clearInterval(detectionInterval);
  }, []);

  if (compact) {
    return (
      <div className="rounded-lg overflow-hidden border border-border">
        <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-surface">
          <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
          <span className="text-xs font-semibold text-primary">Your Camera</span>
        </div>
        <video
          ref={videoRef}
          autoPlay
          muted
          playsInline
          className="w-full aspect-video object-cover"
        />
      </div>
    );
  }

  return (
    <div className="mt-4 flex justify-center">
      <video
        ref={videoRef}
        autoPlay
        muted
        playsInline
        width="400"
        height="300"
        className="rounded-xl border border-border"
      />
    </div>
  );
}