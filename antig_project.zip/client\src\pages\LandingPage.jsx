// client/src/pages/LandingPage.jsx
import { useNavigate } from "react-router-dom";

export default function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Nav */}
      <nav className="relative z-10 flex items-center justify-between px-8 py-5 border-b border-border bg-surface/80 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded bg-primary flex items-center justify-center text-accent font-serif font-bold text-lg border border-accent/20">P</div>
          <span className="text-xl font-serif font-bold text-primary tracking-tight">ProctorAI</span>
        </div>
        <button
          onClick={() => navigate("/login")}
          className="btn-primary"
        >
          Sign In
        </button>
      </nav>

      {/* Hero */}
      <section className="relative z-10 flex flex-col items-center justify-center text-center px-4 pt-24 pb-20">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-surfaceAlt border border-border text-primary text-sm font-medium mb-8 shadow-sm">
          <span className="w-2 h-2 bg-accent rounded-full"></span>
          Academic Integrity Portal
        </div>

        <h1 className="text-5xl md:text-7xl font-serif text-primary leading-tight max-w-4xl mb-6">
          Exams, <span className="gradient-text italic">made remarkable.</span>
        </h1>

        <p className="text-lg text-muted max-w-2xl mb-10 leading-relaxed font-sans">
          Advanced face detection, gaze tracking, and behavior analysis. 
          Ensure exam integrity with multi-layer proctoring powered by 
          computer vision and real-time analytics.
        </p>

        <div className="flex gap-4 mb-16">
          <button
            onClick={() => navigate("/login")}
            className="btn-primary text-lg px-8 py-3"
          >
            Get Started
          </button>
          <button
            onClick={() => document.getElementById("features").scrollIntoView({ behavior: "smooth" })}
            className="btn-outline text-lg px-8 py-3"
          >
            Learn More
          </button>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="relative z-10 px-8 pb-24 max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              title: "PostgreSQL",
              desc: "Structured data — users, exams, questions, scores, and audit trails with full relational integrity.",
            },
            {
              title: "MongoDB",
              desc: "Unstructured data — video session metadata, frame analysis results, and suspicious event logs.",
            },
            {
              title: "Redis",
              desc: "Real-time caching — live risk scores, active sessions, and instant pub/sub for proctor alerts.",
            },
          ].map((feature, i) => (
            <div key={i} className="card p-8">
              <h3 className="text-xl font-serif font-bold text-primary mb-3">
                {feature.title}
              </h3>
              <p className="text-muted text-sm leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </div>

        {/* Second row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
          {[
            {
              title: "AI Face Detection",
              desc: "Browser-based face-api.js detects no face, multiple faces, and gaze direction every 2 seconds. Weighted scoring system minimizes false positives.",
            },
            {
              title: "Dual Stream Monitoring",
              desc: "Webcam + screen share streamed simultaneously to proctor dashboard via Socket.IO. Full visibility for real-time intervention.",
            },
          ].map((feature, i) => (
            <div key={i} className="card p-8 bg-primary text-white border-primary">
              <h3 className="text-xl font-serif font-bold text-accent mb-3">
                {feature.title}
              </h3>
              <p className="text-gray-300 text-sm leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-border bg-surface px-8 py-8 text-center text-muted text-sm font-serif">
        ProctorAI System — Academic Integrity & Cheating Detection
      </footer>
    </div>
  );
}
