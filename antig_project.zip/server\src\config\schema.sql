-- ═══════════════════════════════════════════════════════
-- ONLINE PROCTORING SYSTEM — PostgreSQL Schema
-- ═══════════════════════════════════════════════════════

-- USERS (students, proctors, admins)
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('student', 'proctor', 'admin')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- QUESTIONS (from friend's schema — enhanced)
CREATE TABLE IF NOT EXISTS questions (
    id SERIAL PRIMARY KEY,
    question_text TEXT NOT NULL,
    type VARCHAR(30) NOT NULL DEFAULT 'MCQ',
    options JSONB,
    correct_answer TEXT,
    category VARCHAR(100),
    difficulty VARCHAR(50) DEFAULT 'Easy',
    marks INTEGER DEFAULT 1,
    tags TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- EXAMS (from friend's schema — enhanced with status)
CREATE TABLE IF NOT EXISTS exams (
    id SERIAL PRIMARY KEY,
    exam_title VARCHAR(255) NOT NULL,
    duration INTEGER NOT NULL,
    total_marks INTEGER DEFAULT 0,
    start_time TIMESTAMP,
    end_time TIMESTAMP,
    status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft', 'ready', 'live', 'completed')),
    proctoring_settings JSONB DEFAULT '{}',
    created_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- EXAM ↔ QUESTIONS link table (from friend's schema)
CREATE TABLE IF NOT EXISTS exam_questions (
    id SERIAL PRIMARY KEY,
    exam_id INTEGER REFERENCES exams(id) ON DELETE CASCADE,
    question_id INTEGER REFERENCES questions(id) ON DELETE CASCADE
);

-- EXAM REGISTRATIONS
CREATE TABLE IF NOT EXISTS exam_registrations (
    id SERIAL PRIMARY KEY,
    student_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    exam_id INTEGER REFERENCES exams(id) ON DELETE CASCADE,
    status VARCHAR(30) DEFAULT 'registered' CHECK (status IN ('registered', 'in_progress', 'submitted', 'flagged')),
    risk_score INTEGER DEFAULT 0,
    started_at TIMESTAMP,
    submitted_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(student_id, exam_id)
);

-- STUDENT ANSWERS
CREATE TABLE IF NOT EXISTS student_answers (
    id SERIAL PRIMARY KEY,
    student_id INTEGER REFERENCES users(id),
    exam_id INTEGER REFERENCES exams(id),
    question_id INTEGER REFERENCES questions(id),
    selected_answer TEXT,
    answered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(student_id, exam_id, question_id)
);

-- SCORES
CREATE TABLE IF NOT EXISTS scores (
    id SERIAL PRIMARY KEY,
    student_id INTEGER REFERENCES users(id),
    exam_id INTEGER REFERENCES exams(id),
    score INTEGER NOT NULL,
    total INTEGER NOT NULL,
    percentage DECIMAL(5,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(student_id, exam_id)
);

-- DISPUTES
CREATE TABLE IF NOT EXISTS disputes (
    id SERIAL PRIMARY KEY,
    student_id INTEGER REFERENCES users(id),
    exam_id INTEGER REFERENCES exams(id),
    reason TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'reviewing', 'resolved', 'rejected')),
    resolution TEXT,
    resolved_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP
);

-- AUDIT LOG
CREATE TABLE IF NOT EXISTS audit_log (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    action VARCHAR(100) NOT NULL,
    details JSONB DEFAULT '{}',
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- SEED default users
INSERT INTO users (name, email, password, role)
VALUES
  ('Admin User', 'admin@proctor.com', 'admin123', 'admin'),
  ('Dr. Proctor', 'proctor@proctor.com', 'proctor123', 'proctor'),
  ('Student One', 'student@proctor.com', 'student123', 'student'),
  ('Student Two', 'student2@proctor.com', 'student123', 'student')
ON CONFLICT (email) DO NOTHING;
