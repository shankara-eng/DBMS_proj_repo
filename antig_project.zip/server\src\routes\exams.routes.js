// server/src/routes/exams.routes.js
import express from "express";
import { authenticateToken, requireRole } from "../middleware/auth.js";
import {
  createExam, getExams, getExam, updateExamStatus,
  addQuestionsToExam, getExamQuestions, registerForExam,
  getMyExams, startExam, getExamStudents
} from "../controllers/exams.controller.js";

const router = express.Router();

// IMPORTANT: Static paths MUST come before /:id dynamic paths

// Public
router.get("/", getExams);

// Student — specific path before /:id
router.get("/my-exams", authenticateToken, requireRole("student"), getMyExams);

// Dynamic :id routes
router.get("/:id", getExam);
router.get("/:id/questions", authenticateToken, getExamQuestions);
router.get("/:id/students", authenticateToken, requireRole("proctor", "admin"), getExamStudents);

// Proctor / Admin
router.post("/", authenticateToken, requireRole("proctor", "admin"), createExam);
router.patch("/:id/status", authenticateToken, requireRole("proctor", "admin"), updateExamStatus);
router.post("/:id/questions", authenticateToken, requireRole("proctor", "admin"), addQuestionsToExam);

// Student actions
router.post("/:id/register", authenticateToken, requireRole("student"), registerForExam);
router.post("/:id/start", authenticateToken, requireRole("student"), startExam);

export default router;