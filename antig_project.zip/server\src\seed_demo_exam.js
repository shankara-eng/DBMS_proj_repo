import pg from 'pg';
import dotenv from 'dotenv';
dotenv.config();

const { Pool } = pg;

const pool = new Pool({
  user: process.env.PG_USER || "postgres",
  host: process.env.PG_HOST || "localhost",
  database: process.env.PG_DATABASE || "proctor_system",
  password: process.env.PG_PASSWORD || "PSQL",
  port: parseInt(process.env.PG_PORT) || 5432,
});

const questions = [
  { text: "What is the capital of France?", options: ["London", "Berlin", "Paris", "Madrid"], answer: "C" },
  { text: "Which planet is known as the Red Planet?", options: ["Earth", "Mars", "Jupiter", "Venus"], answer: "B" },
  { text: "What is 2 + 2?", options: ["3", "4", "5", "6"], answer: "B" },
  { text: "Who wrote 'Romeo and Juliet'?", options: ["Charles Dickens", "William Shakespeare", "Mark Twain", "Jane Austen"], answer: "B" },
  { text: "What is the largest mammal in the world?", options: ["Elephant", "Blue Whale", "Giraffe", "Hippopotamus"], answer: "B" },
  { text: "In computing, what does CPU stand for?", options: ["Central Process Unit", "Computer Personal Unit", "Central Processing Unit", "Central Processor Unit"], answer: "C" },
  { text: "Which element has the chemical symbol 'O'?", options: ["Gold", "Oxygen", "Osmium", "Oganesson"], answer: "B" },
  { text: "What is the boiling point of water at sea level?", options: ["90°C", "100°C", "120°C", "80°C"], answer: "B" },
  { text: "Which continent is the Sahara Desert located on?", options: ["Asia", "South America", "Africa", "Australia"], answer: "C" },
  { text: "How many legs does a spider have?", options: ["6", "8", "10", "12"], answer: "B" },
  { text: "What is the hardest natural substance on Earth?", options: ["Gold", "Iron", "Diamond", "Platinum"], answer: "C" },
  { text: "Who painted the Mona Lisa?", options: ["Vincent van Gogh", "Pablo Picasso", "Leonardo da Vinci", "Claude Monet"], answer: "C" },
  { text: "What is the main ingredient in guacamole?", options: ["Tomato", "Onion", "Avocado", "Pepper"], answer: "C" },
  { text: "Which country is home to the kangaroo?", options: ["South Africa", "Australia", "New Zealand", "India"], answer: "B" },
  { text: "What is the smallest prime number?", options: ["0", "1", "2", "3"], answer: "C" }
];

async function seedData() {
  try {
    // 1. Get the admin user ID
    const userRes = await pool.query("SELECT id FROM users WHERE email = 'admin@proctor.com'");
    const adminId = userRes.rows.length > 0 ? userRes.rows[0].id : 1;

    // 2. Create the Exam
    const examRes = await pool.query(
      `INSERT INTO exams (exam_title, duration, total_marks, status, created_by)
       VALUES ($1, $2, $3, $4, $5) RETURNING id`,
      ["Demo Exam: General Knowledge", 30, 15, "live", adminId]
    );
    const examId = examRes.rows[0].id;
    console.log(`Created Exam ID: ${examId}`);

    // 3. Insert Questions and link them
    for (const q of questions) {
      const qRes = await pool.query(
        `INSERT INTO questions (question_text, type, options, correct_answer, category, difficulty, marks)
         VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`,
        [q.text, 'MCQ', JSON.stringify(q.options), q.answer, 'General', 'Easy', 1]
      );
      const qId = qRes.rows[0].id;

      await pool.query(
        `INSERT INTO exam_questions (exam_id, question_id) VALUES ($1, $2)`,
        [examId, qId]
      );
    }
    
    console.log("Successfully added 15 questions and linked them to the exam.");
  } catch (err) {
    console.error("Error seeding data:", err);
  } finally {
    pool.end();
  }
}

seedData();
